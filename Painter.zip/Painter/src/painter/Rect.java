package painter;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Rect extends Stamp{
	
	/**
	 * create a new rectangle shape
	 */
	public Rect() {
		shape = new Rectangle();
	}
	
	/**
	 * render the rectangle to the screen
	 */
	void render(Graphics2D g) {
		((Rectangle) shape).setLocation(super.getX(), super.getY());
		((Rectangle) shape).setSize(super.getSize());
		
		g.setColor( getColor() );
		g.fill(shape);
	}
	
	/**
	 * return a new rectangle
	 */
	public Stamp newStamp(){
		return new Rect();
	}
}

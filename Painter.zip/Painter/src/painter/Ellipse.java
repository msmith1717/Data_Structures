package painter;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RectangularShape;

public class Ellipse extends Stamp{
	//private Ellipse2D shape;
	
	//create a new ellipse
	public Ellipse() {
		shape = new Ellipse2D.Double();
	}
	
	//render the ellipse
	public void render(Graphics2D g) {
		
		Dimension dim = super.getSize();
		((RectangularShape) shape).setFrame(super.getX(), super.getY(), dim.width, dim.height);
		
		g.setColor( getColor() );
		g.fill(shape);
	}
	
	//return a new ellipse
	public Stamp newStamp() {
		return new Ellipse();
	}
}

package painter;
import java.awt.*;


public abstract class Stamp{
	
	protected Shape shape;
	private float x, y, width, height;
	private Color color;
	private boolean fill;
	private int init_width, init_height, init_multiplier;
	
	/**
	 * resets the stamp
	 */
	public Stamp() {
		reset();
	}
	/**
	 * returns the stamp
	 * @return
	 */
	public Shape rtnShape(){
		return shape;
	}
	
	/**
	 * sets size and location to 0,0
	 * sets color of stamp to black 
	 */
	public void reset(){
		this.setSize(0, 0);
		this.setLocation(0, 0);
		this.color = Color.BLACK;
		this.fill = false;
	}
	
	/**
	 * returns if stamp is filled
	 * @return
	 */
	public boolean isFilled() {
		return fill;
	}
	
	/**
	 * sets filled to boolean in parameters 
	 * @param filled
	 */
	public void setFilled( boolean filled ){
		this.fill = filled;
	}
	
	/**
	 * sets size of stamp to given floats passed in as parameters
	 * @param width
	 * @param height
	 */
	public void setSize( float width, float height ){
		this.width = width;
		this.height = height;
	}
	
	public void setInitialSize(int width, int height, int multiplier){
		this.init_height = height;
		this.init_width = width;
		this.init_multiplier = multiplier;
	}
	
	public int getInitialMultiplier(){
		return this.init_multiplier;
	}
	
	public void setLocation( float x, float y ){
		this.x = x;
		this.y = y;
	}
	
	public boolean invertedY(){
		if( height < 0 ){
			return true;
		}
		return false;
	}
	
	public boolean invertedX() {
		if( width < 0 ){
			return true;
		}
		return false;
	}
	
	public int getX() {
		int x = Math.round( this.x );
		return x;
	}
	
	public int getY() {
		int y = Math.round(this.y);
		return y;
	}
	
	public Dimension getSize() {
		Dimension rtn = new Dimension();
		rtn.width = Math.abs(Math.round(this.width));
		rtn.height = Math.abs(Math.round(this.height));
		return rtn;
	}
	
	public Dimension getInitialSize() {
		Dimension rtn = new Dimension();
		rtn.width = Math.abs(Math.round(this.init_width));
		rtn.height = Math.abs(Math.round(this.init_height));
		return rtn;
	}
		
	boolean setColor( Color c ){
		boolean rtn = false;
		if( c != null ) {
			this.color = c;
			rtn = true;
		}
		return rtn;
	}
	Color getColor(){
		return this.color;
	}
	
	abstract void render( Graphics2D g );
	abstract Stamp newStamp();

}

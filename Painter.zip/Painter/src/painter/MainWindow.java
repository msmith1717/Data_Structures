package painter;
import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class MainWindow extends JFrame{

	private DrawingPane drawing;
	private Image delete_shapes;
	private JPanel toolbar = new JPanel();
	private JPanel slider = new JPanel();

	//window is given a string to title its jframe
	//the delete image is loaded and a toolbar object is added to the frame
	//a key listener is attached to the toolbar that deletes the top most stamp
	//a stamp size slider is added to the mainwindow
	public MainWindow( String title ) {
		super( title );
		try {
			BufferedImage i = ImageIO.read(new File("Img/delete.png"));
			delete_shapes =  i.getScaledInstance(60, 60, Image.SCALE_DEFAULT);
		}catch (IOException e) {
			e.printStackTrace();
		}

		JPanel toolbar = setupToolbar();
		toolbar.setBackground(new Color(255, 128, 128));
		drawing = new DrawingPane();	

		setLayout( new BorderLayout() );
		add( toolbar, BorderLayout.WEST);
		add( drawing, BorderLayout.CENTER);
		add( slider, BorderLayout.SOUTH);
		
		final int MUTLIPLIER_MIN = 0;
		final int MUTLIPLIER_MAX = 100;
		final int MUTLIPLIER_INIT = 50;    //initial frames per second
		JSlider sizeSlider = new JSlider(JSlider.HORIZONTAL,MUTLIPLIER_MIN, MUTLIPLIER_MAX, MUTLIPLIER_INIT);
		sizeSlider.addChangeListener(new SliderListener());
		sizeSlider.setFocusable(false);
		toolbar.add(sizeSlider);

		//Turn on labels at major tick marks.
		sizeSlider.setMajorTickSpacing(50);
		sizeSlider.setMinorTickSpacing(10);
		sizeSlider.setPaintTicks(true);
		sizeSlider.setPaintLabels(true);
		Font font = new Font("Serif", Font.ITALIC, 15);
		sizeSlider.setFont(font);
		slider.add(sizeSlider);
		slider.setBackground(new Color(255,128,128));

		toolbar.setFocusable(true);
		toolbar.requestFocusInWindow(); //when you press delete key you lose focus from other buttons
		toolbar.addKeyListener(new KeyListener(){
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub			
			}
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if(e.getKeyCode() == 8){
					drawing.removeTop();
				}		
			}
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}	
		});

		requestFocus();
	}

	//a button for each shape is added to the toolbar
	//along with a button that deletes all stamps
	public JPanel setupToolbar() {
		toolbar.setLayout( new BoxLayout(toolbar, BoxLayout.Y_AXIS));

		Stamp[] stamps = { new Rect(), new Ellipse(), new Triangle(), new Pentagon()};

		toolbar.add(Box.createGlue());
		for( Stamp s : stamps ){
			Tool t = new Tool( s );
			t.setPreferredSize(new Dimension(60,60));
			t.addActionListener( new BtnListener() );
			toolbar.add( t );
		}

		ImageIcon delete = new ImageIcon(delete_shapes);
		JButton clear_pane = new JButton(delete);
		clear_pane.setFocusable(false);
		clear_pane.addActionListener( new clearBtn() );
		toolbar.add(clear_pane);

		toolbar.add(Box.createGlue());
		return toolbar;		
	}


	public class SliderListener implements javax.swing.event.ChangeListener{

		//if the value for the stamp size slider is changed, all the shapes are multiplied by the new value
		public void stateChanged(ChangeEvent e) {
			JSlider source = (JSlider)e.getSource();
			if (!source.getValueIsAdjusting()) {
				int multiplier = (int)source.getValue();
				if(multiplier == 0){
					multiplier++;
				}
				drawing.adjustSizeMultiplier(multiplier); 
			} 
		}

	}

	public class BtnListener implements ActionListener
	{

		//if a tool button is pressed, create a new stamp with that shape
		public void actionPerformed(ActionEvent e) {
			Tool t = (Tool) e.getSource();		
			Stamp newStamp = t.getStamp().newStamp();
			newStamp.setSize(0, 0);
			drawing.setSelected(newStamp);
		}
	}

	public class clearBtn implements ActionListener
	{

		//if clear button is pressed, delete all shapes from drawing pane
		public void actionPerformed(ActionEvent e) {
			drawing.resetPane();
		}
	}



}

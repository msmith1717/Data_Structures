package painter;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Polygon;

public class Triangle extends Stamp {
	//private Polygon shape;
	
	public Triangle() {
		shape = new Polygon();
	}

	@Override
	public void render(Graphics2D g) {
		int x = super.getX();
		int y = super.getY();
		Dimension dim = super.getSize();
		
		((Polygon) shape).reset();
		
		if( super.invertedY() ){
			((Polygon) shape).addPoint(x+dim.width/2, y+dim.height);
		}
		else {
			((Polygon) shape).addPoint(x+dim.width/2, y);
			y += dim.height;
		}
		((Polygon) shape).addPoint(x, y);
		((Polygon) shape).addPoint(x+dim.width, y);
		
		g.setColor( getColor() );
		g.fill(shape);
	}
	
	@Override
	public Stamp newStamp() {
		return new Triangle();
	}
}

package painter;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class DrawingPane extends JPanel{

	private Stamp selected;
	private LList<Stamp> shapes;
	private Random rand;
	private int multiplier = 50;

	//initialize mouse, mouse listeners, and rand variable 
	public DrawingPane() {
		shapes = new LList<Stamp>();

		rand = new Random();
		Mouser mouser = new Mouser();
		this.addMouseListener(mouser);
		this.addMouseMotionListener(mouser);
	}

	//deletes all shapes from arraylist as well as the selected shape
	//then repaints 
	public void resetPane(){
		selected.setSize(0, 0);
		shapes.clear();
		repaint();
	}
	
	//adjusts all the sizes of the shapes according to the given multiplier
	public void adjustSizeMultiplier(int multiplier){
		this.multiplier = multiplier;
		for(int i = 0; i < shapes.size(); i++){
			shapes.get(i).setSize(shapes.get(i).getInitialSize().width * multiplier/shapes.get(i).getInitialMultiplier(), shapes.get(i).getInitialSize().height * multiplier/shapes.get(i).getInitialMultiplier());
		}
		repaint();
	}
	//removes the top shape from the shape arraylist then repaints
	public void removeTop(){
		if(shapes.size() > 0){
			shapes.remove(shapes.size()-1);
		}
		selected.setSize(0, 0);
		repaint();
	}

	//sets selected stamp to the passed in stamp
	//as long as it is not null
	public boolean setSelected( Stamp toUse ){
		boolean rtn = false;
		if( toUse != null ){
			this.selected = toUse;
			rtn = true;
		}
		return rtn;
	}

	//returns the selected stamp
	public Stamp getSelected(){
		return selected;
	}

	//renders all the shapes in the shape arraylist to the screen
	public void paintComponent( Graphics g ){
		Graphics2D g2 = (Graphics2D) g;

		for( Stamp s : shapes ){
			s.render(g2);
		}

		if( selected != null ){    
			selected.render(g2);
		}

	}

	private class Mouser implements MouseListener, MouseMotionListener{

		private int anchorX, anchorY;
		private boolean did_drag_start = false;

		@Override
		public void mouseClicked(MouseEvent e) {
		}

		//if mouse is clicked create a new stamp with random color
		public void mousePressed(MouseEvent e) {
				did_drag_start = false;	

				Stamp current = getSelected();

				if( current == null){
					return;
				}

				current = current.newStamp();
				current.reset();

				current.setColor( new Color( rand.nextInt(255), rand.nextInt(255), rand.nextInt(255)));
				current.setLocation(e.getX(), e.getY());

				anchorX = e.getX();
				anchorY = e.getY();
				setSelected(current);

		}

		@Override
		//if mouse was dragged once mouse is released, then create a new stamp
		//else move the top most shape that was clicked on to the top of all the stamps
		public void mouseReleased(MouseEvent e) {
			if(did_drag_start){
				if( getSelected() == null){
					return;
				}
				shapes.add(getSelected());
				selected = selected.newStamp();
			}else{
				boolean flag = true;
				for(int i = shapes.size() - 1; i >= 0 && flag; i--){
					if(shapes.get(i).rtnShape().contains(anchorX, anchorY)){
						shapes.add(shapes.get(i));  
						shapes.remove(i);
						flag = false;
						repaint();
					}
				}
			}
		}

		@Override
		public void mouseEntered(MouseEvent e) {

		}

		@Override
		public void mouseExited(MouseEvent e) {

		}

		@Override
		//if mouse is dragged, get the x,y values of the initial click
		//and find the width and height of the stamp
		public void mouseDragged(MouseEvent e) {
			Stamp selected = getSelected();

			if( selected == null ){
				return;
			}

			int x = selected.getX();
			int y = selected.getY();

			int width = e.getX() - anchorX;
			int height = e.getY() - anchorY;	

			if( width < 0 )
			{
				x = e.getX();
			}

			if( height < 0 ){
				y = e.getY();
			}

			if(x > 2 && y > 2){
				did_drag_start = true;
			}
			
			selected.setLocation( x, y);
			selected.setSize( width, height);
			selected.setInitialSize(width, height, multiplier);
			repaint();
		}

		@Override
		public void mouseMoved(MouseEvent e) {

		}

	}

}

package painter;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Polygon;

//this class was created with the intent of being a pentagon, hence the name
//creative choices lead me to create an octagon instead
public class Pentagon extends Stamp{

	//create a new polygon
	public Pentagon() {
		shape = new Polygon();
	}
	
	//render all points of the octagon
	public void render(Graphics2D g) {
		int x = super.getX();
		int y = super.getY();
		Dimension dim = super.getSize();
		
		((Polygon) shape).reset();

		
		((Polygon) shape).addPoint(x - dim.width/2, y - dim.height);
		((Polygon) shape).addPoint(x - dim.width, y - dim.height/2);
		((Polygon) shape).addPoint(x - dim.width, y + dim.height/2);
		((Polygon) shape).addPoint(x - dim.width/2, y + dim.height);
		
		((Polygon) shape).addPoint(x + dim.width/2, y + dim.height);
		((Polygon) shape).addPoint(x + dim.width, y + dim.height/2);
		((Polygon) shape).addPoint(x + dim.width, y - dim.height/2);
		((Polygon) shape).addPoint(x + dim.width/2, y - dim.height);
		
		g.setColor( getColor() );
		g.fill(shape);
	}

	/**
	 * return a new pentagon
	 */
	Stamp newStamp() {
		return new Pentagon();
	}

}

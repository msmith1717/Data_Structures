import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;



public class AngledRect{
	public static JFrame f;


	public static void main(String[] args) {
		
		System.out.println(-123%10);
		f = new JFrame("Black Square");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MyPanel panel = new MyPanel();
		f.add(panel);
		f.pack();
		panel.startTimer();
		f.setVisible(true);
	}

}

class MyPanel extends JPanel{
	public int prefW = 700;
	public int prefH = 500;
	private ArrayList<Integer> keysPressed = new ArrayList<Integer>();
	private Timer timerFast = new Timer();
	private Timer timerSlow = new Timer();
	private Sword firstSword = new Sword(prefW - 120);
	private Walls walls = new Walls(prefW, prefH);
	private Image backGround;
	private Image castle;
	private Image hand;
	private Image pauseSign;
	private Image playSign;
	private ArrayList<Enemy> firstEnemy = new ArrayList<Enemy>();
	private int counterDead = 0; 
	private int numEnemy = 1;
	public int highScore = 1;
	public JButton pause = new JButton();
	public boolean timersStopped = false;
	public int spinDegree = 0;



	public MyPanel() {
		for(int i = 0; i < numEnemy; i++){
			firstEnemy.add(new Enemy());
		}
		try {
			BufferedImage i = ImageIO.read(new File("Img/YellowClouds.jpg"));
			backGround =  i.getScaledInstance(prefW, prefH, Image.SCALE_DEFAULT);
			i = ImageIO.read(new File("Img/PauseSign.jpg"));
			pauseSign =  i.getScaledInstance(25, 25, Image.SCALE_DEFAULT);
			i = ImageIO.read(new File("Img/PlaySign.jpg"));
			playSign =  i.getScaledInstance(25, 25, Image.SCALE_DEFAULT);
		} catch (IOException e) {
			e.printStackTrace();
		}
		firstSword.setPrefs(prefW, prefH);
		for(int i = 0; i < firstEnemy.size(); i++){
			firstEnemy.get(i).setPrefs(prefW, prefH, i, numEnemy);
		}
		ImageIcon controlTime = new ImageIcon(pauseSign);
		pause = new JButton(controlTime);
		pause.setFocusable(false);
		pause.addActionListener(new BtnListener());
		this.setLayout(null);
		pause.setBounds(prefW - 30, 0, 30, 30);
		this.add(pause);

		AngledRect.f.addKeyListener( new KeyListener() {
			public void keyPressed(KeyEvent e) {
				if(timersStopped == false){
					if(!keysPressed.contains(e.getKeyCode())){
						keysPressed.add(new Integer(e.getKeyCode()));
					}
					if(keysPressed.contains(KeyEvent.VK_SPACE)){
						if(firstSword.inSwing == false && firstSword.stamina > 0){
							firstSword.inSwing = true;
							firstSword.degreeBeforeSwing = firstSword.degree;
						}

					}
					if(keysPressed.contains(KeyEvent.VK_1)){
						firstSword.swordOut = true;
					}
					if(keysPressed.contains(KeyEvent.VK_2)){
						firstSword.swordOut = false;
					}
					if(keysPressed.contains(KeyEvent.VK_RIGHT) && !(keysPressed.contains(KeyEvent.VK_SHIFT))){
						firstSword.directionX = firstSword.moveSpeed;
					}
					if(keysPressed.contains(KeyEvent.VK_LEFT) && !(keysPressed.contains(KeyEvent.VK_SHIFT))){
						firstSword.directionX = -1 * firstSword.moveSpeed;
					}

					if(keysPressed.contains(KeyEvent.VK_RIGHT) && keysPressed.contains(KeyEvent.VK_SHIFT) && firstSword.stamina > 0){
						firstSword.directionX = 3 * firstSword.moveSpeed;
						firstSword.isRun = true;
					}
					if(keysPressed.contains(KeyEvent.VK_LEFT) && keysPressed.contains(KeyEvent.VK_SHIFT) && firstSword.stamina > 0){
						firstSword.directionX = -3 * firstSword.moveSpeed;
						firstSword.isRun = true;
					}
					if(keysPressed.contains(KeyEvent.VK_LEFT) && keysPressed.contains(KeyEvent.VK_RIGHT)){
						firstSword.directionX = 0;
					}
					if(keysPressed.contains(KeyEvent.VK_UP) && firstSword.stamina > 0){
						if(firstSword.ifJumping == false && firstSword.ifFalling == false){
							firstSword.ifJumping = true;
							firstSword.jumpVelocity = firstSword.jumpSpeed;
						}else if(firstSword.ifJumping == true && firstSword.doubleJumpActive == false){
							firstSword.ifJumping = true;
							firstSword.ifFalling = false;
							firstSword.doubleJumpActive = true;						
							firstSword.jumpVelocity = firstSword.jumpSpeed;
							firstSword.fallVelocity = 0;
						}				
					}
					if(keysPressed.contains(KeyEvent.VK_DOWN) && !(keysPressed.contains(KeyEvent.VK_SPACE))){
						if(firstSword.ifJumping && firstSword.ifFalling == false){
							firstSword.ifFalling = true;
							firstSword.fallVelocity = 0;
						}
					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {	
				if(timersStopped == false){
					keysPressed.remove(new Integer(e.getKeyCode()));
				}
			}

			@Override
			public void keyTyped(KeyEvent e) {

			}

		});

		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {

			}
		});

		addMouseMotionListener(new MouseAdapter() {
			public void mouseDragged(MouseEvent e) {

			}
		});

	}
	public class BtnListener implements ActionListener{
		public void actionPerformed( ActionEvent e ){
			pauseGame();
		}
	}
	public void pauseGame(){
		if(timersStopped == false){
			timersStopped = true;
			ImageIcon controlTime = new ImageIcon(playSign);
			pause.setIcon(controlTime);
		}else{
			timersStopped = false;
			ImageIcon controlTime = new ImageIcon(pauseSign);
			pause.setIcon(controlTime);
		}
		repaint();
	}

	TimerTask taskFast = new TimerTask() {
		public void run() {
			if(timersStopped == false){
				spinDegree++;
				if(numEnemy > highScore){
					highScore = numEnemy;
				}
				if(firstSword.alive){
					if(firstSword.didWin == false){
						firstSword.determineLife();
						firstSword.decideIfRun(keysPressed);
						firstSword.decideWhichSide();
						//firstSword.determineJumpAttack();
						firstSword.swingSword();
						firstSword.moveSword();
						firstSword.updateRect();
						firstSword.determineHitBox();
						firstSword.movePews();
						firstSword.updatePews();
						firstSword.removePews();
						firstSword.determineGroundLevel(walls.rects);
						for(int i = 0; i < firstEnemy.size(); i++){
							if(firstEnemy.get(i).visible){
								firstEnemy.get(i).updateRect();
								if(firstEnemy.get(i).alive){
									firstEnemy.get(i).moveEnemy();
									firstEnemy.get(i).determineLife();
									firstEnemy.get(i).attackDetection(firstSword);
									firstEnemy.get(i).defenseDetection(firstSword);
									firstEnemy.get(i).determineGroundLevel(walls.rects);
								}
							}else{
								firstEnemy.remove(i);
							}
						}
						if(firstEnemy.size() == 0){
							numEnemy++;
							firstSword.didWin = true;
						}
					}else{
						restart(true);
					}
				}else{
					restart(false);
				}
				repaint();
			}
		}};
		public void restart(Boolean didWin){
			counterDead++;
			if(counterDead == 100){
				if(didWin){
					firstSword.showVictory = true;
				}else{
					firstSword.deathVisible = true;
				}		
			}
			if(counterDead == 300){
				if(didWin == false){
					numEnemy = 1;
				}
				firstSword = new Sword(prefW - 120);
				firstSword.setPrefs(prefW, prefH);
				firstEnemy.clear();
				for(int i = 0; i < numEnemy; i++){
					firstEnemy.add(new Enemy());
					firstEnemy.get(i).setPrefs(prefW, prefH, i, numEnemy);
				}
				counterDead = 0;
				walls = new Walls(prefW, prefH);
			}
		}

		TimerTask taskSlow = new TimerTask() {
			public void run() {
				if(timersStopped == false){
					if(firstSword.alive){
						firstSword.jumpSquare();
						for(int i = 0; i < firstEnemy.size(); i++){
							if(firstEnemy.get(i).visible){
								if(firstEnemy.get(i).alive){
									//firstEnemy.get(i).choseDirection(firstSword);
									//firstEnemy.get(i).determineJump(firstSword);
									firstEnemy.get(i).jumpSquare();
								}else{
									firstEnemy.get(i).shrinkRect();
								}
							}
						}
					}

				}
			}};
			TimerTask taskVerySlow = new TimerTask() {
				public void run() {
					if(timersStopped == false){
						if(firstSword.alive){
							for(int i = 0; i < firstEnemy.size(); i++){
								if(firstEnemy.get(i).visible){
									firstEnemy.get(i).choseDirection(firstSword);
									firstEnemy.get(i).determineJump(firstSword);
								}
							}
						}
					}
				}};

				public void startTimer(){		
					timerFast.scheduleAtFixedRate(taskFast, 1000, 10);
					timerSlow.scheduleAtFixedRate(taskSlow, 1000, 30);
					timerSlow.scheduleAtFixedRate(taskVerySlow, 1000, 100); //fix this 
				}

				public Dimension getPreferredSize() {
					return new Dimension(prefW, prefH);
				}

				protected void paintComponent(Graphics g) {
					Graphics2D g2 = (Graphics2D) g;
					super.paintComponent(g2);
					g2.drawImage(backGround, 0, 0, null);
					paintSpinnyThing(g2);
					paintSword(g2);
					paintWalls(g2);
					paintEnemy(g2);
					paintHUD(g2);
			        
					
					//Ellipse2D ball = new Ellipse2D.Double(100, 100, 50, 10);
					//double theta = Math.toRadians(0);
					//AffineTransform transform = new AffineTransform();
					//transform.rotate(theta, 100, 100); 
					//ball = (Ellipse2D) transform.createTransformedShape(ball);
					

					
					
					
					
				}
				public void paintSpinnyThing(Graphics2D g2){
					g2.setColor(Color.black);
					for (double i = 0; i < 360 ; i += 10) {
				    	Shape e = new Ellipse2D.Double(prefW-3, -100, 6, 200);
				    	AffineTransform at = AffineTransform.getRotateInstance(Math.toRadians(i + spinDegree), prefW, 0);
				    	e = at.createTransformedShape(e);
				        g2.draw(e); 
					}	
				}
				
				public void paintSword(Graphics2D g2){
					if(firstSword.swordOut){
						g2.setColor(Color.lightGray);
						g2.fill(firstSword.rotatedRectStaff);
						g2.setColor(Color.BLACK);
						g2.fill(firstSword.secondHandle);
						g2.setColor(Color.BLACK);
						g2.fill(firstSword.rotatedRectHandle);
						g2.setColor(Color.lightGray);
						g2.fill(firstSword.tip);
					}else{
						Color brown = new Color(165, 42, 42);
						g2.setColor(brown);
						g2.fill(firstSword.rotatedRectStaff);
						g2.setColor(Color.BLUE);
						g2.fill(firstSword.tip);
					}
					for(int i = 0; i < firstSword.pew.size(); i++){
						g2.setColor(Color.BLUE);
						for(int k = 0; k < firstSword.pew.get(i).spikes.size(); k++){
							g2.fill(firstSword.pew.get(i).spikes.get(k));
						}
						g2.setColor(Color.CYAN);
						g2.fill(firstSword.pew.get(i).ball);
					}

					Color orangeSkin = new Color(255,173,96);
					Color brownSkin = new Color	(234,192,134);
					Color pinkSkin = new Color	(255,205,148);
			        for(int i = 0; i < firstSword.hand.size(); i++){
			        	if(i == 0){
			        		g2.setColor(brownSkin);
			        	}else{
			        		g2.setColor(pinkSkin);
			        	}
			        	
			        	Shape s = firstSword.hand.get(i);
			        	g2.fill(s);
			        	g2.setColor(Color.black);
			        	g2.draw(s); 
			        }
					if(firstSword.deathVisible){
						int x = 250;
						g2.setColor(Color.RED);
						g2.setFont(new Font("TimesRoman", Font.BOLD, 50));
						g2.drawString("You Died", x, 150);
						g2.setColor(Color.BLACK);
						g2.setFont(new Font("TimesRoman", Font.BOLD, 50));
						g2.drawString("You Died", x+5, 150);
					}
				}
				public void paintHUD(Graphics2D g2){
					g2.setColor(Color.BLACK);
					g2.fillRect(0, prefH-50, prefW, 50);
					g2.setColor(Color.GRAY);
					g2.drawRect(0, prefH-50, prefW, 50);
					g2.setColor(Color.WHITE);
					g2.fillRect(100, prefH-35, firstSword.staminaMax/3, 10); //white stamina under everything
					g2.setColor(Color.GREEN);
					g2.setFont(new Font("TimesRoman", Font.PLAIN, 20));
					g2.drawString("Stamina: ", 25, prefH-25); //says "stamina"
					g2.fillRect(100, prefH-35, firstSword.stamina/3, 10); //actual stamina bar
					g2.setColor(Color.GRAY);
					g2.drawRect(100, prefH-35, firstSword.staminaMax/3, 10); //the outline of stamina bar
					g2.setColor(Color.WHITE);
					g2.fillRect(475, prefH-35, firstSword.healthMax/3, 10); //white health under everything
					g2.setColor(Color.RED);
					g2.drawString("Health: ", 400, prefH-25);// says "health"
					g2.fillRect(475, prefH-35, firstSword.health/3, 10); //actual health bar that moves
					g2.setColor(Color.GRAY);
					g2.drawRect(475, prefH-35, firstSword.healthMax/3, 10); //outline of health bar
					g2.setColor(Color.BLACK);
					g2.setFont(new Font("TimesRoman", Font.PLAIN, 20));
					g2.drawString("Round: " + numEnemy, 10, 15);
					g2.drawString("Highscore: " + highScore, 10, 30);
					if(timersStopped){
						Color opqaueBlue = new Color(220, 225, 227, 127);
						g2.setColor(opqaueBlue);
						g2.fillRect(0,0, prefW, prefH);
						g2.setFont(new Font("TimesRoman", Font.BOLD, 50));
						g2.setColor(Color.BLACK);
						g2.drawString("Paused", prefW/2-75, 250);
					}

				}
				public void paintEnemy(Graphics2D g2){
					for(int i = 0; i < firstEnemy.size(); i++){
						if(firstEnemy.get(i).visible){
							if(firstEnemy.get(i).ifAttacking == false){
								g2.setColor(Color.BLACK);
							}else{
								g2.setColor(Color.RED);
							}
							g2.fill(firstEnemy.get(i).rect);
							g2.setColor(Color.lightGray);
							g2.draw(firstEnemy.get(i).rect);
							if(firstEnemy.get(i).alive){
								g2.setColor(Color.RED);
								g2.fillRect((int)firstEnemy.get(i).x,(int)firstEnemy.get(i).y-10, firstEnemy.get(i).health/4, 4);
								if(firstEnemy.get(i).takingDamage){
									g2.setColor(Color.yellow);
								}else{
									g2.setColor(Color.lightGray);
								}
								g2.drawRect((int)firstEnemy.get(i).x,(int)firstEnemy.get(i).y-10, firstEnemy.get(i).healthMax/4, 4);
							}
						}
					}
					if(firstSword.showVictory){
						int x = 250;
						g2.setColor(Color.GREEN);
						g2.setFont(new Font("TimesRoman", Font.BOLD, 50));
						g2.drawString("You Survived", x-50, 150);
						g2.setColor(Color.BLACK);
						g2.setFont(new Font("TimesRoman", Font.BOLD, 50));
						g2.drawString("You Survived", x-45, 150);
					}
				}
				public void paintWalls(Graphics2D g2){
					for(int i = 0; i < walls.rects.size(); i++){
						try {
							BufferedImage k = ImageIO.read(new File("Img/castle.jpg"));
							castle =  k.getSubimage(0, 0, walls.rects.get(i).width, walls.rects.get(i).height); //errors appear on this line sometimes
						} catch (IOException e) {
							e.printStackTrace();
						}
						g2.drawImage(castle, walls.rects.get(i).x, walls.rects.get(i).y, null);
					}
				}
}

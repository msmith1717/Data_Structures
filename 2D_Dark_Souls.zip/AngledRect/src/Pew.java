import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;

public class Pew {
	public Rectangle projectile;
	public int x;
	public int y;
	public int width = 10;
	public int height = 10;
	public int direction;
	public ArrayList<Polygon> spikes = new ArrayList<Polygon>();
	public Polygon tip;
	public int radius = 12;
	public Ellipse2D ball;
	public int degree = 0;
	public int triangleHeight = 20;
	public int triangleWidth = 4;

	public Pew(int x, int y, boolean facingLeft){
		if(facingLeft){
			direction = -3;
		}else{
			direction = 3;
		}
		this.x = x;
		this.y = y;
		projectile = new Rectangle(this.x, this.y, width, height);
	}
	public void moveProjectile(){
		this.x += direction;
	}
	public void updateProjectile(){
		//projectile = new Rectangle(this.x, this.y, width, height);
		spikes = new ArrayList<Polygon>();
		for(int k = 0; k < 360; k+= 20){
			tip = new Polygon();	
			Point2D[] triangle = new Point[3];
			triangle[0] = new Point(x + triangleHeight, y); //right
			triangle[1] = new Point(x + 4, y - triangleWidth);
			triangle[2] = new Point(x + 4, y + triangleWidth);
			for(int i = 0; i < triangle.length; i++){
				AffineTransform transform = new AffineTransform();
				transform.rotate(k, x, y);
				triangle[i] = transform.transform(triangle[i], triangle[i]);
				tip.addPoint((int)triangle[i].getX(),(int)triangle[i].getY());
			}
			spikes.add(tip);
		}

		/*
		tip2 = new Polygon();	
		triangle[0] = new Point(x - 16, y); //left
		triangle[1] = new Point(x - 4, y -4);
		triangle[2] = new Point(x - 4, y + 4);
		for(int i = 0; i < triangle.length; i++){
			tip2.addPoint((int)triangle[i].getX(),(int)triangle[i].getY());
		}
		tip3 = new Polygon();	
		triangle[0] = new Point(x, y + 16); //bottom
		triangle[1] = new Point(x + 4, y + 4);
		triangle[2] = new Point(x - 4, y + 4);
		for(int i = 0; i < triangle.length; i++){
			tip3.addPoint((int)triangle[i].getX(),(int)triangle[i].getY());
		}
		tip4 = new Polygon();	
		triangle[0] = new Point(x, y - 16); //top
		triangle[1] = new Point(x + 4, y - 4);
		triangle[2] = new Point(x - 4, y - 4);
		for(int i = 0; i < triangle.length; i++){
			tip4.addPoint((int)triangle[i].getX(),(int)triangle[i].getY());
		}
		 */
		ball = new Ellipse2D.Double(x - .5 * radius, y - .5 * radius, radius , radius);
	}
}

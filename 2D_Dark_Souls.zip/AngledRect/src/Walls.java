import java.awt.Rectangle;
import java.util.ArrayList;

public class Walls {
	public ArrayList<Rectangle> rects = new ArrayList<Rectangle>();
	public int sizeDif = 60;

	public Walls(int prefW, int prefH){
		prefH -= 150;
		prefW -= 30; 
		int randLength = (int)(Math.random()*7)+2;	
		for(int i = 0; i < randLength; i++){
				Rectangle rect = new Rectangle((int)(Math.random()*prefW), (int)(Math.random()*prefH), 100, 30);
				int intersectionCount = 0;
				for(int k = 0; k < rects.size(); k++){
					Rectangle biggerRect = new Rectangle((int)(rects.get(k).x- .5 * sizeDif),(int)(rects.get(k).y-.5 * sizeDif), rects.get(k).width + sizeDif, rects.get(k).height + sizeDif);
					if(biggerRect.intersects(rect)){
						intersectionCount++;
					}
				}
				if(intersectionCount == 0){
					rects.add(rect);
				}
			}
	}
}

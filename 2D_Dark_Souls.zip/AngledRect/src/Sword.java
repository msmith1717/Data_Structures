import java.awt.Image;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.AffineTransformOp;
import java.util.ArrayList;

public class Sword {
	public int xF = 200;
	public int yF = 200;
	public Shape rotatedRectStaff;
	public Shape rotatedRectHandle;
	public ArrayList<Shape> hand = new ArrayList<Shape>();
	//public Image hand;
	public Shape secondHandle;
	public Rectangle hitBox = new Rectangle();
	public Polygon tip = new Polygon();
	public int height = 8;
	public int degree = -50;
	public int swingSize = 70;
	public int swingSpeed = 3;
	public int degreeBeforeSwing;
	public int stamina;
	public int staminaLoss;
	public int staminaMax;
	public boolean inSwing = false;
	public boolean afterSwing = false;
	public boolean isRun = false;
	public int prefW;
	public int prefH;
	public int moveSpeed = 2;
	public int directionX = 0;
	public boolean ifJumping = false;
	public boolean ifFalling = false;
	public boolean doubleJumpActive = false;
	public int jumpVelocity = 0;
	public int fallVelocity = 0;
	public int groundLevel; 
	public int jumpSpeed = 15;
	public int healthMax;
	public int health;
	public int damage = 3;
	public boolean facingLeft = false;
	public boolean jumpAttackActive = false;
	public boolean alive = true;
	public boolean deathVisible = false;
	public boolean didWin = false;
	public boolean showVictory = false;
	public boolean swordOut = true;
	public boolean shooting = false;
	public ArrayList<Pew> pew = new ArrayList<Pew>();
	public int pewCount;

	public Sword(int xF, int yF, int degree, int swingSpeed){
		this.xF = xF;
		this.yF = yF;
		this.degree = degree;
		this.swingSpeed = swingSpeed;
	}
	public Sword(int stamina){
		this.staminaMax = stamina;
		this.stamina = stamina;
		this.staminaLoss = stamina/120;
		healthMax = staminaMax;
		health = healthMax;
	}
	public void setPrefs(int prefW, int prefH){
		this.prefW = prefW;
		this.prefH = prefH;
		groundLevel = prefH-70;
		yF = groundLevel-230;
		xF = prefW/2;
		updateRect();
	}
	public void determineHitBox(){
		if(facingLeft == false){
			hitBox = new Rectangle(xF-10, yF-35, 50, 50); 
		}else{
			hitBox = new Rectangle(xF-25, yF-35, 50, 50); 
		}
	}
	//public void determineJumpAttack(){
	//	if(ifJumping && inSwing){
	//		jumpAttackActive = true;
	//	}
	//}
	public void determineLife(){
		if(health <= 0){
			alive = false;
		}
	}
	public void moveSword(){
		xF += directionX;
		if(xF < 40){
			xF = 40;
		}
		if(yF < 0){
			yF = 0;
		}
		if(xF > prefW-40){
			xF = prefW-40;
		}
		if(yF > prefH+30){
			yF = prefH+30;
		}

	}
	public void updateRect(){
		int width = 135;
		double theta ;
		theta = Math.toRadians(degree);
		tip = new Polygon();	
		Point2D[] triangle = new Point[3];
		triangle[0] = new Point(xF, yF -width+5);
		triangle[1] = new Point((int)(xF + .5 * height), yF - width - 15);;
		triangle[2] = new Point(xF + height, yF - width+5);
		for(int i = 0; i < triangle.length; i++){
			double newTheta = Math.toRadians(degree+92);
			AffineTransform transform = new AffineTransform();
			transform.rotate(newTheta, xF + (.5 * height), yF);
			triangle[i] = transform.transform(triangle[i], triangle[i]);
			tip.addPoint((int)triangle[i].getX(),(int)triangle[i].getY());
		}
		Rectangle2D rect = new Rectangle2D.Double(xF, yF, width, height);
		AffineTransform transform = new AffineTransform();
		transform.rotate(theta, xF + (.5 * height), yF); 
		rotatedRectStaff = transform.createTransformedShape(rect);
		width = 35;
		rect = new Rectangle2D.Double(xF, yF, width, height);
		transform = new AffineTransform();
		transform.rotate(theta, xF + (.5 * height), yF); 
		secondHandle = transform.createTransformedShape(rect);
		int x = xF-24;
		int y = yF +30;
		width = 40;
		theta = Math.toRadians(degree-90);
		rect = new Rectangle2D.Double(x+3, y, width, height);
		transform = new AffineTransform();
		transform.rotate(theta, xF + (.5 * height), yF); 
		rotatedRectHandle = transform.createTransformedShape(rect);
		if(facingLeft == false){
			x = xF - 5;
			y = yF - 15;
		}else{
			x = xF - 10;
			y = yF - 20;
		}
		//g2.fillOval(200, 200, 30, 25);
		hand.clear();
		Shape e = new Ellipse2D.Double(x, y, 30, 20);
		hand.add(e);
		//g2.fillOval(215, 205, 16, 6);
		e = new Ellipse2D.Double(x+15, y+2, 16, 5);
		hand.add(e);
		//g2.fillOval(215, 210, 16, 6);
		e = new Ellipse2D.Double(x+15, y+7, 16, 5);
		hand.add(e);
		//g2.fillOval(215, 215, 16, 6);
		e = new Ellipse2D.Double(x+15, y+12, 16, 5);
		hand.add(e);
		int newHeight = height + 10;
		if(facingLeft == false){
			theta = theta - Math.toRadians(220);
		}else{
			theta = theta - Math.toRadians(-40);
		}
		for(int i = 0; i < hand.size(); i++){
			AffineTransform at = AffineTransform.getRotateInstance(theta, x + 15, y + 10);
			Shape newHand = at.createTransformedShape(hand.get(i));
			hand.set(i, newHand);
		}
	}

	public void movePews(){
		for(int i = 0; i < pew.size(); i++){
			pew.get(i).moveProjectile();
		}
	}
	public void updatePews(){
		for(int i = 0; i < pew.size(); i++){
			pew.get(i).updateProjectile();
		}
	}
	public void removePews(){
		for(int i = 0; i < pew.size(); i++){
			if(pew.get(i).x > prefW || pew.get(i).x < 0){
				pew.remove(i);
				i--;
			}
		}
	}

	public void createWandProjectile(){
		if(swordOut == false){
			if(facingLeft){
				if(degree < degreeBeforeSwing - .5 * swingSize){
					shooting = true;
				}else{
					shooting = false;
				}
			}else{
				if(degree > degreeBeforeSwing + .5 * swingSize ){
					shooting = true;
				}else{
					shooting = false;
				}
			}
			if(shooting && pewCount == 0){
				int xChange;
				if(facingLeft){
					xChange = -40;
				}else{
					xChange = 40;
				}
				pew.add(new Pew(xF + xChange, yF, facingLeft));
			}
			if(shooting){
				pewCount++;
			}else{
				pewCount = 0;
			}
		}
	}
	public void swingSword(){
		if(inSwing && afterSwing == false){
			stamina-=staminaLoss;
			if(facingLeft == false){
				if(degree < degreeBeforeSwing + swingSize){
					degree+= swingSpeed;
				}else{
					afterSwing = true;
				}
			}else{
				if(degree > degreeBeforeSwing - swingSize){
					degree-= swingSpeed;
				}else{
					afterSwing = true;
				}
			}
			createWandProjectile();
		}else if(inSwing && afterSwing){
			stamina-=staminaLoss;
			if(facingLeft == false){
				if(degree > degreeBeforeSwing){
					degree-=swingSpeed;
				}else{
					afterSwing = false;
					inSwing = false;
				}  
			}else{
				if(degree < degreeBeforeSwing){
					degree+=swingSpeed;
				}else{
					afterSwing = false;
					inSwing = false;
				}
			}
		}else if(inSwing == false && ifJumping == false){
			if(stamina < staminaMax && isRun == false){
				stamina+=2;
			}
		}
	}
	public void decideIfRun(ArrayList<Integer> keysPressed){
		if(directionX == 3 * moveSpeed || directionX == -3 * moveSpeed){
			stamina--;
		}else{
			isRun = false;
		}
	}
	public void decideWhichSide(){
		if(inSwing == false){
			if(directionX < 0){
				degree = -130;
				facingLeft = true;
			}else{
				degree = -50;
				facingLeft = false;
			}
		}
	}
	public void determineGroundLevel(ArrayList<Rectangle> rects){
		int countCol = 0;
		for(int i = 0; i < rects.size(); i++){
			if(rects.get(i).intersects(hitBox)){
				groundLevel = rects.get(i).y - 14;    
				countCol++;
			}
		}
		if(countCol == 0){
			groundLevel = prefH-70;
			if(yF < groundLevel && ifJumping == false){
				ifFalling = true;
				ifJumping = true;
				doubleJumpActive = false;
				fallVelocity = 0;
			}
		}
	}
	public void jumpSquare(){
		if(ifJumping){
			stamina-=staminaLoss;
			if(ifFalling == false){
				if(jumpVelocity > 0){
					if(yF < 0){
						yF = 0;
					}else{
						yF-= jumpVelocity;
					}
					moveSword();
					jumpVelocity--;
				}else{
					ifFalling = true;
					fallVelocity = 0;
				}
			}else{
				if(yF < groundLevel){	
					yF+= fallVelocity;
					fallVelocity++;
				}else{
					yF = groundLevel;
					ifJumping = false;
					ifFalling = false;
					doubleJumpActive = false;
				}
			}
		}else if(yF > groundLevel){
			yF = groundLevel;
		}
	}

}

import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

public class Enemy {
	public int x;
	public int y;
	public int width = 25;
	public int height = 25;
	public int health = 100;
	public int healthMax = 100;
	public int directionX;
	public int moveSpeed = 1;
	public int prefW;
	public int prefH;
	public int damage = 1;
	public Shape rect;
	public boolean faceLeft = true;
	public boolean alive = true;
	public boolean visible = true;
	public boolean ifJumping = false;
	public boolean ifFalling = false;
	public int jumpVelocity = 0;
	public int fallVelocity = 0;
	public int groundLevel; 
	public int jumpSpeed = 15;
	public boolean ifAttacking = false;
	public int degree = 0;
	public boolean takingDamage = false;


	public void setPrefs(int prefW, int prefH, int i, int iMax){
		this.prefW = prefW;
		this.prefH = prefH;
		int changeBy = prefW/iMax;
		y = (int)(Math.random()*(prefH -50 - height));
		x = i * changeBy;
		rect = new Rectangle(x, y, width, height);
		groundLevel = prefH-70;
		updateRect();
	}
	public void updateRect(){
		double theta = Math.toRadians(degree);
		rect = new Rectangle(x, y, width, height);
		AffineTransform transform = new AffineTransform();
		transform.rotate(theta, x + (.5 * width), y + (.5 * height)); 
		rect = transform.createTransformedShape(rect);
	}
	public void choseDirection(Sword firstSword){
		if(x <= firstSword.xF-40){
			int rand = (int)(Math.random()*100);
			if(rand <= 55){
				faceLeft = false;
			}
		}else if(x >= firstSword.xF +40){
			int rand = (int)(Math.random()*100);
			if(rand <= 55){
				faceLeft = true;
			}
		}
		if(x <= 0){
			faceLeft = false;
		}else if(x >= prefW - width){
			faceLeft = true;
		}
		if(faceLeft){
			directionX = -1 * moveSpeed;	
		}else{
			directionX = moveSpeed;
		}
	}
	public void moveEnemy(){
		x += directionX;
	}
	public void determineGroundLevel(ArrayList<Rectangle> rects){
		int countCol = 0;
		for(int i = 0; i < rects.size(); i++){
			Rectangle newRect = new Rectangle(x, y, width, height);
			if(rects.get(i).intersects(newRect)){
				groundLevel = rects.get(i).y - 24;    
				countCol++;
			}
		}
		if(countCol == 0){
			groundLevel = prefH-70;
			if(y < groundLevel && ifJumping == false){
				ifFalling = true;
				ifJumping = true;
				fallVelocity = 0;
			}
		}
	}
	public void attackDetection(Sword firstSword){
		if(rect.intersects(firstSword.hitBox)){
			ifAttacking = true;
			degree+=3;
			firstSword.health-= damage;
		}else{
			ifAttacking = false;
			degree = 0;
		}
	}
	public void defenseDetection(Sword firstSword){
		Rectangle newRect = new Rectangle(x, y, width, height);
		int healthBefore = health;
		if(firstSword.inSwing && firstSword.swordOut){
			if(firstSword.rotatedRectHandle.intersects(newRect) || firstSword.rotatedRectStaff.intersects(newRect) || firstSword.tip.intersects(newRect)){
				health-= firstSword.damage;
			}
		}
		for(int i = 0; i < firstSword.pew.size(); i++){
			int countIntersect = 0;
			for(int k = 0; k < firstSword.pew.get(i).spikes.size(); k++){
				if( firstSword.pew.get(i).spikes.get(k).intersects(newRect)){
					countIntersect++;
				}
			}
			if(countIntersect > 0){
				health-= firstSword.damage;
			}
		}
		if(healthBefore == health){
			takingDamage = false;
		}else{
			takingDamage = true;
		}
	}
	public void determineJump(Sword firstSword){
		if(y >= firstSword.yF + 20 && ifJumping == false){
			int rand = (int)(Math.random()*100);
			if(rand <= 60){
				ifJumping = true;
				jumpVelocity = jumpSpeed;
			}
		}	
	}
	public void determineLife(){
		if(health <= 0){
			alive = false;
		}
	}
	public void shrinkRect(){
		if(alive == false){
			degree = 0;
			y--;
			if(width > 0 && height > 0){
				width--;
				height--;
			}else{
				visible = false;
			}
		}
	}
	public void jumpSquare(){
		if(ifJumping){
			if(ifFalling == false){
				if(jumpVelocity > 0){
					if(y < 0){
						y = 0;
					}else{
						y-= jumpVelocity;
					}
					jumpVelocity--;
				}else{
					ifFalling = true;
					fallVelocity = 0;
				}
			}else{
				if(y < groundLevel){	
					y+= fallVelocity;
					fallVelocity++;
				}else{
					y = groundLevel;
					ifJumping = false;
					ifFalling = false;
				}
			}
		}else if(y > groundLevel){
			y = groundLevel;
		}
	}
}

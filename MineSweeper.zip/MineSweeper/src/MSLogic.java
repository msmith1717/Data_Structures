import java.awt.geom.Point2D;
import java.util.ArrayList;

import javax.swing.JButton;

//runs the logic in the game
public class MSLogic {
	// 0-9 = count, 10 = mine, -100 = uncovered zero space
	// negative number = uncovered
	private int[][] board; 
	public MSLogic(int width, int height){
		reset(width, height);
	}

	/**
	 * Resets the board with new dimensions
	 * @param width the width of the board in spaces
	 * @param height the height of the board in spaces
	 */
	//creates the board with set width and height
	public void reset( int width, int height ){
		// Recreate the board
		board = new int[width][height];
		reset();
	}

	/**
	 * Resets the board of the game without 
	 * changing its dimensions
	 */
	public void reset() {
		// Reset the board to all zeros
		// place Mines with a 15 percent chance
		// recalculate the spaces
		placeMines(15);
		calcSpaces();

		for(int row = 0; row < board.length; row++){
			for(int col = 0; col < board[row].length; col++){
				if(board[row][col] != -10){
					System.out.print(" " + -1 * board[row][col] + " ");
				}else{
					System.out.print(" M ");
				}
			}
			System.out.println();
		}
		System.out.println();


	}

	//places mines with a 15% chance
	private void placeMines( int chance ) {
		for(int row = 0; row < board.length; row++){
			for(int col = 0; col < board[row].length; col++){
				board[row][col] = 0;
				int realChance = (int)(Math.random()*100);
				if(realChance < chance){
					board[row][col] = -10;
				}
			}
		}
	}

	//calculates the value of each tile on board
	private void calcSpaces() {
		for(int row = 0; row < board.length; row++){
			for(int col = 0; col < board[row].length; col++){
				if(board[row][col] != -10){
					int countMines = 0;
					if(col > 0){ //left
						if(board[row][col - 1] == -10){
							countMines++;
						}
					}
					if(col < board[row].length - 1){ //right
						if(board[row][col + 1] == -10){
							countMines++;
						}
					}
					if(row > 0){ //up
						if(board[row - 1][col] == -10){
							countMines++;
						}
					}
					if(row < board.length - 1){ //down
						if(board[row + 1][col] == -10){
							countMines++;
						}
					}
					if(col < board[row].length - 1 && row > 0){ //right, up
						if(board[row - 1][col + 1] == -10){
							countMines++;
						}
					}
					if(col > 0 && row > 0){ //left, up
						if(board[row - 1][col - 1] == -10){
							countMines++;
						}
					}
					if(col > 0 && row < board.length- 1){ //left, down
						if(board[row + 1][col - 1] == -10){
							countMines++;
						}
					}
					if(col < board[row].length - 1 && row < board.length - 1){ //right, down
						if(board[row + 1][col + 1] == -10){
							countMines++;
						}
					}
					if(countMines == 0){
						board[row][col] = -100;
					}else{
						board[row][col] = -1 * countMines;
					}
				}
			}
		}
	}

	/**
	 * Makes a move on the board
	 * @param x the x-coordinate to move (zero is on the left)
	 * @param y the y-coordinate to move (zero is on the top)
	 * @return true if a mine is hit, false otherwise
	 */
	//makes the index of board passed in visible, and if it's a zero it calls makeMove() around it
	public boolean makeMove( int x, int y ){

		// Make a move at (x,y) if possible
		// Reveal all spaces around (x,y) that are zero

		board[x][y] = Math.abs(board[x][y]);
		if(board[x][y] == 100){
			if(y > 0){ //left
				if(board[x][y - 1] < 0){
					makeMove(x, y - 1);
				}
			}
			if(y < board[x].length - 1){ //right
				if(board[x][y + 1] < 0){
					makeMove(x, y + 1);
				}
			}
			if(x > 0){ //up
				if(board[x - 1][y] < 0){
					makeMove(x - 1, y);
				}
			}
			if(x < board.length - 1){ //down
				if(board[x + 1][y] < 0){
					makeMove(x + 1, y);
				}
			}
			
			if(x > 0 && y < board[x].length - 1){ //diagonal: up right
				if(board[x - 1][y + 1] < 0){
					makeMove(x - 1, y + 1);
				}
			}
			if(x > 0 && y > 0){ //diagonal: up left
				if(board[x - 1][y - 1] < 0){
					makeMove(x - 1, y - 1);
				}
			}
			if(x < board.length - 1 && y < board[x].length - 1){ //diagonal down right
				if(board[x + 1][y + 1] < 0){
					makeMove(x + 1, y + 1);
				}
			}
			if(x < board.length - 1 && y > 0){ //diagonal down left
				if(board[x + 1][y - 1] < 0){
					makeMove(x + 1, y - 1);
				}
			}
			
		}
		return true;
	}

	/**
	 * Returns the status of one space on the board
	 * @param x the x-coordinate of the space (0 is on the left)
	 * @param y the y-coordinate of the space (0 is on the top)
	 * @return the number of mines around the space (0-9), a mine (10), or -1 if a space has not be selected
	 */
	//returns the value of the specified index of the array board
	public int getSpace( int x, int y ){
		int boardValue = board[x][y];
		if(boardValue < 0){
			boardValue = -1;
		}
		return boardValue;
	}

	/**
	 * Determine is the game is over
	 * @return true if the game is over, false otherwise
	 */
	//returns an int value that represents the status of the board
	//if any mines are visible, the game is over
	//if no pieces are hidden, then the player won
	//else the game is ongoing
	public int isGameOver() {
		int gameState = 0; //0 = ongoing, 1 = win, -1 = loss
		int hiddenPieces = 0;
		for(int row = 0; row < board.length; row++){
			for(int col = 0; col < board[row].length; col++){
				if(board[row][col] < 0 && board[row][col] != -10){
					hiddenPieces++;
				}
				if(board[row][col] == 10){
					return -1;
				}
			}
		}
		if(hiddenPieces == 0){
			gameState = 1;
		}
		return gameState;
	}
}
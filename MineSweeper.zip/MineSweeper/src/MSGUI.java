
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Scanner;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContentDisplay;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Duration;

public class MSGUI extends BorderPane{
	private Button[][] board;
	private MSLogic logic;
	private Image mine; 
	private Image flag;
	private Image buttonColor;
	private int time = 0;
	private boolean isControlDown;
	private Text text = new Text();
	private int highScore = 0;
	private Stage stageScore = new Stage();
	private Stage stage; 
	private BorderPane topThis = new BorderPane();
	private int width;
	private int height;
	private ArrayList<String> availableScores = new ArrayList<String>();
	private ArrayList<String> availableAreas = new ArrayList<String>();

	//creates an array of buttons with the specified dimensions
	//adds reset button
	//adds highScore button, which creates a page that displays all the highscores
	//adds appropriate images to buttons dependent on their values in logic
	public MSGUI(Stage stage, int width, int height) {
		this.stage = stage;
		this.width = width;
		this.height = height;

		highScore = Integer.parseInt(getHighScore());

		java.io.FileInputStream confederate;
		java.io.FileInputStream bomb;
		java.io.FileInputStream buttonStyle;

		//load images
		try {
			bomb = new FileInputStream("Img/bomb.png");
			confederate = new FileInputStream("Img/confederateFlag.jpg");
			buttonStyle = new FileInputStream("Img/tileTexture.jpg");

			mine = new Image(bomb, 30 , 30 , false, true);
			flag = new Image(confederate, 30,30, false, true);
			buttonColor = new Image(buttonStyle, 30, 30, false, true);

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		this.setTop(topThis);


		//add score text
		text.setFont(new Font(15));
		text.setWrappingWidth(200);
		text.setTextAlignment(TextAlignment.CENTER);
		topThis.setLeft(text);
		BorderPane.setAlignment(text, Pos.TOP_LEFT); //WHY DOESN'T THIS DO ANYTHING!!!!!!!!!!!!!!!!!


		// Initialize the board array and the logic
		GridPane panel = new GridPane();
		panel.setAlignment(Pos.CENTER);
		this.setCenter(panel);
		BorderPane.setMargin(panel, new Insets(15)); //bind to width of borderpane  
		BorderPane.setAlignment(panel, Pos.CENTER);			//NEED TO SET THE PANE TO THE MIDDLE OF BORDERPANE
		this.setStyle("-fx-background-color: linear-gradient(from 25% 25% to 100% 100%, #993399, #0099ff) ");


		//add reset button
		Button reset = new Button("Reset"); //bind to width of borderpane
		reset.setMinSize(width * 40 + 2 * 15, 20);
		reset.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent arg0) {
				gameOver(true);
			}
		});
		this.setBottom(reset);
		BorderPane.setAlignment(reset, Pos.BOTTOM_CENTER);

		Button highScores = new Button("Highscores");
		highScores.setMinSize(10, 10);
		highScores.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				BorderPane highScores = new BorderPane();
				Scene scoreScene = new Scene(highScores, 500, 500);
				stageScore.setScene(scoreScene);
				stageScore.show();
				stage.hide();
				//displayHighScores(highScores);

				//create button to return to game 
				Button game = new Button("Game");
				game.setOnAction(new EventHandler<ActionEvent>(){

					public void handle(ActionEvent arg0) {
						stageScore.hide();
						stage.show();
					}
				});
				highScores.setBottom(game);
				BorderPane.setAlignment(game, Pos.BOTTOM_LEFT);

				Text highScoreText = new Text(" HighScores: ");
				highScoreText.setFont(new Font(25));
				highScoreText.setWrappingWidth(0);
				BorderPane.setAlignment(highScoreText, Pos.TOP_CENTER);
				highScores.setTop(highScoreText); 

				getHighScore();
				sortScores();

				GridPane panelHS = new GridPane();
				panelHS.setAlignment(Pos.CENTER);
				highScores.setCenter(panelHS);
				BorderPane.setMargin(panelHS, new Insets(15));   
				BorderPane.setAlignment(panelHS, Pos.CENTER);	


				int col = 0;
				for(int i = 0; i < availableScores.size(); i++){
					col = i/15;
					Text highScoreList = new Text();
					highScoreList.setText(availableAreas.get(i) + " Tiles: " + availableScores.get(i) + " Seconds");
					highScoreList.setFont(new Font(15));
					panelHS.add(highScoreList, col, (i)%15);
					System.out.println("row: " + ((i+1)%15));
				}


			}
		});
		topThis.setRight(highScores);
		BorderPane.setAlignment(highScores, Pos.TOP_RIGHT);

		logic = new MSLogic(width, height);
		board = new Button[width][height];

		this.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent mouseEvent) {
				if(mouseEvent.isControlDown()){
					isControlDown = true;
					ActionEvent ae = new ActionEvent(mouseEvent.getSource(), mouseEvent.getTarget());
					Event.fireEvent( mouseEvent.getTarget(), ae );
				}else{
					isControlDown = false;
				}

			}
		});


		// Attach the ActionListeners to the JButtons
		for(int row = 0; row < board.length; row++){
			for(int col = 0; col < board[row].length; col++){
				board[row][col] = new Button();
				BackgroundImage backgroundImage = new BackgroundImage( buttonColor, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
				Background background = new Background(backgroundImage);
				board[row][col].setBackground(background);
				board[row][col].setMinSize(40, 40);
				board[row][col].setMaxSize(40, 40);
				board[row][col].setOnAction(new EventHandler<ActionEvent>(){

					@Override
					public void handle(ActionEvent e) {
						Button b = (Button)e.getSource();
						for( int row = 0; row < board.length; row++ ){
							for(int col = 0; col < board[row].length; col++){
								// if button is in the board
								if( b == board[row][col] ){
									if(isControlDown){	//ctrl
										if(board[row][col].getGraphic() == null && logic.getSpace(row, col) == -1){
											board[row][col].setContentDisplay(ContentDisplay.CENTER);
											board[row][col].setGraphic(new ImageView(flag));
											//board[row][col].setText("F");
										}else if(board[row][col].getGraphic() != null){
											board[row][col].setGraphic(null);
											board[row][col].setText(" ");
										}
									}else{
										if(board[row][col].getGraphic() == null){
											logic.makeMove(row, col);
											updateBoard();	
											gameOver(false);
										}
									}	
								}
							}
						}
					}

				});
				panel.add(board[row][col], row, col);
			}
		}


		//addComponentListener(new CheckVisibleListener());

		// Setup the window with width*height JButtons
		Timeline timeline = new Timeline(new KeyFrame(
				Duration.millis(1000),
				ae -> timerTask()));
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
	}
	//increments the time every second
	//changes the value of the string that tells the player their current score and the all time highscore
	private void timerTask(){
		time++;
		String highScoreString = " HS: " + highScore/60;
		if(highScore%60 < 10){
			highScoreString += ":0" + (highScore%60);
		}else{
			highScoreString += ":" + (highScore%60);
		}
		//if(highScore == -1){
		//	highScoreString = " HS: NA";
		//}
		if(time%60 < 10){
			text.setText("Score: " + time/60 + ":0" + (time%60) + highScoreString);
		}else{
			text.setText("Score: " + time/60 + ":" + (time%60) + highScoreString);
		}

	}


	// Updates the board to reflect the logic
	//it adjusts the images of the buttons to accurately reflect their values in logic
	private void updateBoard() {
		for(int row = 0; row < board.length; row++){
			for(int col = 0; col < board[row].length; col++){
				if(logic.getSpace(row, col) >= 0){
					if(logic.getSpace(row, col) == 10){
						board[row][col].setContentDisplay(ContentDisplay.CENTER);
						board[row][col].setGraphic(new ImageView(mine));
					}else if(logic.getSpace(row, col) == 100){
						board[row][col].setText("0");
						board[row][col].setGraphic(null);
					}else{
						board[row][col].setText("" + logic.getSpace(row, col));
						board[row][col].setGraphic(null);
					}
				}else{
					if(board[row][col].getGraphic() == null){
						board[row][col].setText(" ");
						board[row][col].setGraphic(null);
					}
				}
			}
		}

	}
	//uses a bubble sort to sort the highScore values 
	private void sortScores(){
		boolean changeMade = true;
		while(changeMade == true){
			changeMade = false;
			for(int i = 0; i < availableAreas.size() - 1; i++){
				if(Integer.parseInt(availableAreas.get(i)) > Integer.parseInt(availableAreas.get(i+1))){
					String holderArea = availableAreas.get(i);
					availableAreas.set(i, availableAreas.get(i+1));
					availableAreas.set(i + 1, holderArea);

					String holderScore = availableScores.get(i);
					availableScores.set(i, availableScores.get(i+1));
					availableScores.set(i + 1, holderScore);

					changeMade = true;
				}
			}
		}
	}
	//reads from highScore.txt and returns the current highScore for the appropriate area
	private String getHighScore(){
		FileReader fileReader = null;
		//BufferedReader reader = null;
		Scanner reader = null;
		try {
			fileReader = new FileReader("highScore.txt");
			reader = new Scanner(fileReader);
			availableAreas.clear();
			availableScores.clear();
			String applicableScore = "" + (width * height * 2);
			while (reader.hasNextLine()) {
				String line = reader.nextLine();
				String[] score = line.split(":"); //score[0] is area, score[1] is score
				availableAreas.add(score[0]);
				availableScores.add(score[1]);
				if(Integer.parseInt(score[0]) == width * height){
					applicableScore = score[1];// process the line
				}
			}
			return applicableScore;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return "0";
		} 
		finally{
			if(reader != null){
				reader.close();
			}
		}
	}

	//prints to highScore.txt the list of highScores retrieved earlier 
	//replaces appropriate area with new highScore
	public void setHighScore(int highScore){
		File scoreFile = new File("highScore.txt");
		if(!scoreFile.exists()){
			try {
				scoreFile.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		FileWriter writeFile = null;
		BufferedWriter writer = null; //mr sea said use PrintWriter
		try{
			writeFile = new FileWriter(scoreFile);
			writer = new BufferedWriter(writeFile);
			String highScoreText = "";
			boolean isAvailable = false;
			for(int i = 0; i < availableScores.size(); i++){
				highScoreText += availableAreas.get(i) + ":";
				if(Integer.parseInt(availableAreas.get(i)) == width * height){
					highScoreText += "" + highScore;
					isAvailable = true;
				}else{
					highScoreText += availableScores.get(i);
				}
				if(i < availableScores.size() - 1){
					highScoreText += System.lineSeparator();
				}
			}
			if(isAvailable == false){
				highScoreText += System.lineSeparator() + (width * height) + ":" + highScore;
			}
			writer.write(highScoreText);
		}catch(Exception e){

		}
		finally{
			if(writer != null){
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	// Runs the game over sequence
	//if the player lost an alert is shown telling them
	//if the player won an alert is shown telling them
	//the player is then asked if they want to continue playing
	//if they want to play again, another game is started 
	private void gameOver(boolean endGame) {
		boolean ifReset = false;
		Alert alert = new Alert(AlertType.INFORMATION);

		if(logic.isGameOver() == -1){
			alert.setTitle("You Died!");
			alert.setHeaderText("Don't Click On Bombs...");
			alert.setContentText("Play Again?"); 
			ifReset = true;
		}else if(logic.isGameOver() == 1){
			if(time < highScore){
				highScore = time;
				setHighScore(highScore);
			}

			alert.setTitle("You Won!");
			alert.setHeaderText("That's Surprising...");
			alert.setContentText("Play Again?");
			ifReset = true;
		}
		if(ifReset){
			for(int row = 0; row < board.length; row++){
				for(int col = 0; col < board[row].length; col++){
					logic.makeMove(row, col);
					updateBoard();
				}
			}
			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK){
				reset();
			}
		}else if(endGame){
			reset();
		}
	}
	
	private void reset(){
		time = 0;
		for(int row = 0; row < board.length; row++){
			for(int col = 0; col < board[row].length; col++){
				board[row][col].setText(" ");
				board[row][col].setGraphic(null);
			}
		}
		logic.reset();
		updateBoard();
	}

}

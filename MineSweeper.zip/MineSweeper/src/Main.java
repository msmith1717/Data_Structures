import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Main extends Application{

	public static void main(String[] args ) {
		launch(args);
	}
	public void start(Stage stage){
		// Ask the user for the width and height of the board
		final int initialValue = 5;
		final Spinner<Integer> spinner1 = new Spinner<Integer>();
		SpinnerValueFactory<Integer> valueFactory1 = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, initialValue);
		spinner1.setValueFactory(valueFactory1);
		final Spinner<Integer> spinner2 = new Spinner<Integer>();
		SpinnerValueFactory<Integer> valueFactory2 = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, initialValue);
		spinner2.setValueFactory(valueFactory2);
		Button endSpin = new Button("Enter");
		
		BorderPane spinPane = new BorderPane();
		spinPane.setStyle("-fx-background-color: linear-gradient(from 25% 25% to 100% 100%, #993399, #0099ff)");
		spinPane.setBottom(endSpin);
		
		BorderPane.setAlignment(spinner1, Pos.CENTER);
		BorderPane.setAlignment(spinner2, Pos.CENTER);
		BorderPane.setAlignment(endSpin, Pos.BOTTOM_CENTER);
		
		GridPane spinGrid = new GridPane();
		spinGrid.add(new Label("Width: "), 0, 0);
		spinGrid.add(new Label("Height: "), 0, 1);
		spinGrid.add(spinner1, 1, 0);
		spinGrid.add(spinner2, 1, 1);
		
		
		spinPane.setCenter(spinGrid);
		BorderPane.setMargin(spinGrid, new Insets(10));
	
		Scene spinScene = new Scene( spinPane );
		stage.setScene(spinScene);
		stage.setResizable(false);
		stage.setTitle("Minesweeper Superior");
		stage.show();
		
		endSpin.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
				MSGUI game = new MSGUI(stage, valueFactory1.getValue(), valueFactory2.getValue());
				Scene primaryScene = new Scene(game);
				stage.setScene(primaryScene);
			}
			
		});
		
		
	}
}


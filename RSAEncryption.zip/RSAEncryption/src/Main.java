import java.math.BigInteger;

import javax.swing.JFrame;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Main extends Application{

	public static void main(String[] args ) {
		launch(args);
	}

	//creates an EncryptedGUI object and sets that as the primary scene
	public void start(Stage stage){
		stage.setResizable(true);
		stage.setTitle("RSA Encryption Program");

		EncryptGUI gui = new EncryptGUI(stage);
		Scene primaryScene = new Scene(gui);
		stage.setScene(primaryScene);

		stage.show();

	}



}

import java.math.BigInteger;
import java.util.Base64;
import java.util.ArrayList;
import java.util.Random;

public class KeyGeneration {
	private BigInteger q;
	private BigInteger p;
	private BigInteger n;
	private BigInteger totient; 
	private BigInteger e;
	private BigInteger d;
	private String encryptedString;
	private String plainTextMessage;
	private int bitLength = 1024;

	//will generate p, q, n, totient, e, and d
	public KeyGeneration(){ //for encrypting a message
		p = computePrime(bitLength); 
		q = computePrime(bitLength);
		n = p.multiply(q);
		totient = computeTotient();
		e = computeE(); //a number with one less bit count than totient who is coprime
		d = computeD();
		
		System.out.println("p is: " + p);
		System.out.println("q is: " + q);
		System.out.println("n is: " + n);
		System.out.println("totient is: " + totient);
		System.out.println("e is: " + e);
		System.out.println("d is: " + d);
	}

	//given the public key (n and e), and a non-encrypted message, this will encrypt the message
	public KeyGeneration(BigInteger n, BigInteger e, String plainTextMessage){
		this.n = n;
		this.e = e;
		this.plainTextMessage = plainTextMessage;
		this.encryptedString = encrypt(this.plainTextMessage);
		System.out.println("encrypted message is: " + encryptedString);
	}
	
	//given the private key (n and d) and an encrypted message, this method will decrypt the message
	public KeyGeneration(String encryptedString, BigInteger n, BigInteger d){
		this.n = n;
		this.d = d;
		this.encryptedString = encryptedString;
		this.plainTextMessage = decrypt(this.encryptedString);
		System.out.println("decrypted message is: " + plainTextMessage);
	}
	
	//this method creates a KeyGeneration with the given public key (n and e)
	public KeyGeneration(BigInteger n, BigInteger e, boolean encrypt){
		this.n = n;
		this.e = e;
	}
	//this method creates a KeyGeneration with the given private key (n and d)
	public KeyGeneration(BigInteger n, BigInteger d){
		this.n = n;
		this.d = d;
	}
 
	//returns n of object
	public BigInteger getN(){
		return this.n;
	}
	
	//returns e of object
	public BigInteger getE(){
		return this.e;
	}

	//returns d of object
	public BigInteger getD(){
		return this.d;
	}

	//returns the encrypted message of object
	public String getEncryptedMessage(){
		return this.encryptedString;
	}

	//returns the decrypted message of object
	public String getMessage(){
		return this.plainTextMessage;
	}
	
	//sets plainTextMessage to the given string
	public void setPlainTextMessage(String plainTextMessage){
		this.plainTextMessage = plainTextMessage;
	}

	//computes a random prime number with the specified bit length
	private BigInteger computePrime(int bitLength){
		BigInteger randPrime = BigInteger.probablePrime(bitLength, new Random());		
		return randPrime;
	}

	//computes the totient of object using p and q
	private BigInteger computeTotient(){
		return p.subtract(BigInteger.ONE).multiply((q.subtract(BigInteger.ONE)));
	}

	//computes a random prime number that is less than the totient 
	private BigInteger computeE(){
		BigInteger numE = BigInteger.probablePrime(bitLength - 1, new Random());
		while (totient.gcd(numE).compareTo(BigInteger.ONE) != 0) {
			numE = BigInteger.probablePrime(bitLength - 1, new Random());
			System.out.println("GCD of " + numE + " is: " + numE.gcd(totient));
		}
		return numE;
	}

	//computes the d using the e and the totient
	private BigInteger computeD(){
		return e.modInverse(totient);
	}

	//encrypts a specified string using the public key (n and e ) and then encodes it into base 64
	public String encrypt(String plainText){
		BigInteger plainMessage = new BigInteger(plainText.getBytes());
		BigInteger encryptedInteger = plainMessage.modPow(e, n);
		return Base64.getEncoder().encodeToString(encryptedInteger.toByteArray());
	}

	//decodes a message from bade 64 and decrypts it using the private key (n and d)
	public String decrypt(String messageDecrypt){
		BigInteger decryptMessage = new BigInteger(Base64.getDecoder().decode(messageDecrypt.getBytes()));
		BigInteger decryptedInteger = decryptMessage.modPow(d, n);
		return new String(decryptedInteger.toByteArray());
	}

}

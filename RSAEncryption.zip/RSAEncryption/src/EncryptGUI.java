import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class EncryptGUI extends BorderPane{

	private ArrayList<String> names = new ArrayList<String>();
	private ArrayList<KeyGeneration> userValues = new ArrayList<KeyGeneration>();	
	private KeyGeneration privateKeys;
	private String name = "";
	private Image background;
	Stage stage;


	//this method sets the size and background of the borderpane
	//it then gets the user info from userList.txt and setsUpKeys
	public EncryptGUI(Stage stage){
		//reads private key txt file, if it reads "null" then acquire name and call addUserInfo 
		java.io.FileInputStream image;
		//load images
		try {
			image = new FileInputStream("Images/matrix.jpg");
			background = new Image(image, 300 , 300 , false, true);

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}


		this.setMinSize(300, 300);
		this.setMaxSize(300, 300);
		BackgroundImage[] images = new BackgroundImage[1];
		images[0] = new BackgroundImage(background, null, null, null, null);
		this.setBackground(new Background(images));

		this.stage = stage;
		getUserInfo();
		setUpKeys();
	}

	//creates two buttons: one labeled encrypt, the other labeled decrypt
	private void determineMethod(){
		Button encrypt = new Button("Encrypt");
		Button decrypt = new Button("Decrypt");

		GridPane buttonGrid = new GridPane();
		buttonGrid.add(encrypt, 0, 0);
		buttonGrid.add(decrypt, 1, 0);


		encrypt.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				determineRecipient();
			}

		});

		decrypt.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				getEncryptedMessage();
				//create method that gets message from text area, changes encryptedMessage accordingly, then calls decrypt
			}

		});

		this.setCenter(buttonGrid);
		BorderPane.setAlignment(buttonGrid, Pos.CENTER);
		BorderPane.setAlignment(encrypt, Pos.CENTER);
		BorderPane.setAlignment(decrypt, Pos.CENTER);

	}

	//if no user info can be found in privateKeys.txt then the user is asked for their name
	private void setUpKeys(){
		ArrayList<String> userPrivateKey = getMessage("privateKey.txt");
		if(userPrivateKey.isEmpty()){ 
			determineName();
		}else{
			determineMethod();
		}

	}

	//clears the center of the borderpane
	private void clearGUI(){
		this.setTop(null);
		this.setCenter(null);
		this.setBottom(null);
	}

	//askes for the user's name and adds it to the userList.txt
	//it then asks the user if they want to encrypt or decrypt
	private void determineName(){
		GridPane nameSelection = new GridPane();
		Text prompt = new Text("What is your name?");
		prompt.setTextAlignment(TextAlignment.CENTER);
		prompt.setFill(Color.web("#32cd32"));
		TextField nameInput = new TextField("UserName");
		Button enterName = new Button("Enter");

		nameSelection.add(prompt, 0, 0);
		nameSelection.add(nameInput, 0, 1);
		nameSelection.add(enterName, 0, 2);

		this.setCenter(nameSelection);
		BorderPane.setAlignment(enterName, Pos.CENTER);

		enterName.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
				//name = nameInput.getText();
				System.out.println("names contains " + nameInput.getText() + " is: " + names.contains(nameInput.getText()));
				if(!(names.contains(nameInput.getText()))){
					name = nameInput.getText();
					//I want it to return the name here 
					addUserInfo(name);
					getUserInfo();
					clearGUI(); 
					determineMethod();  
				}else{
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Username Application");
					alert.setHeaderText(nameInput.getText() + " is Unavailable");
					alert.show();

				}
			}

		});

	}

	//gets the message to be encrypt from plaintTextMessage.txt
	//it then displays the encrypted message to the user
	private void encrypt(int index){ //index of name of recipient in names array
		//get public key from index 
		BigInteger n = userValues.get(index).getN();
		BigInteger e = userValues.get(index).getE();
		ArrayList<String> userMessage = getMessage("plainTextMessage.txt");
		for(int i = 0; i < userMessage.size(); i++){
			if(!userMessage.get(i).equals("")){
				userMessage.set(i, new KeyGeneration(n, e, userMessage.get(i)).getEncryptedMessage());
			}
		}
		setMessage(userMessage, "encryptedMessage.txt");
		displayMessage("Encrypted Message:", "encryptedMessage.txt");
	}

	//displays the contents of the specified file to the user
	//it then prompts the user with two buttons: one labeled restart, the other
	//labeled close
	private void displayMessage(String info, String address){
		clearGUI();
		GridPane textGrid = new GridPane(); 
		Text message = new Text(info);
		message.setTextAlignment(TextAlignment.CENTER);
		message.setFill(Color.web("#32cd32"));
		textGrid.add(message, 0, 0);
		ArrayList<String> encryptedMessage = getMessage(address);
		String stringMessage = "";
		for(int i = 0; i < encryptedMessage.size(); i++){
			stringMessage += encryptedMessage.get(i) + System.lineSeparator();
		}
		TextArea text = new TextArea(stringMessage);
		text.setEditable(false);
		textGrid.add(text, 0, 1);

		this.setCenter(textGrid);

		GridPane buttons = new GridPane();
		Button restart = new Button("Restart");
		Button close = new Button("Close");

		buttons.add(restart, 0, 0);
		buttons.add(close, 0, 1);

		this.setBottom(buttons);
		BorderPane.setAlignment(buttons, Pos.CENTER);

		restart.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				clearGUI();
				setUpKeys();
			}

		});

		close.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				stage.hide();
			}

		});

		this.setBottom(buttons);
	}

	//gets the encrypted message from encryptedMessage.txt
	//gets the user's private key 
	//decrypts the encrypted message with the user's private key
	public void decrypt(){//needs to decrypt with same encryption keys 
		//we need to decrypt with our private key
		getPrivateKey();
		ArrayList<String> encryptedMessage = getMessage("encryptedMessage.txt");
		for(int i = 0; i < encryptedMessage.size(); i++){
			if(!encryptedMessage.get(i).equals("")){
				encryptedMessage.set(i, new KeyGeneration(encryptedMessage.get(i), privateKeys.getN(), privateKeys.getD()).getMessage());
			}
		}
		setMessage(encryptedMessage, "plainTextMessage.txt");
		displayMessage("Decrypted Message:", "plainTextMessage.txt");
	}

	public void determineRecipient(){
		GridPane grid = new GridPane();
		Text text = new Text("Recipient:");
		text.setTextAlignment(TextAlignment.CENTER);
		text.setFill(Color.web("#32cd32"));
		ObservableList<String> options = FXCollections.observableArrayList(names);
		ComboBox comboBox = new ComboBox(options);
		Text info = new Text("Message:");
		info.setTextAlignment(TextAlignment.CENTER);
		info.setFill(Color.web("#32cd32"));
		TextArea message = new TextArea();
		Button enter = new Button("Enter");
		
		getPrivateKey();

		Label label1 = new Label("You Are:");
		label1.setTextFill(Color.web("#32cd32"));
		TextField textField = new TextField (this.name);
		textField.setEditable(false);
		HBox hb = new HBox();
		hb.getChildren().addAll(label1, textField);
		
		grid.add(hb, 0, 0);
		grid.add(text, 0, 1);
		grid.add( comboBox, 0, 2);
		grid.add(info, 0, 3);
		grid.add(message, 0, 4);
		grid.add(enter, 0, 5);
		
		
		this.setCenter(grid);
		BorderPane.setAlignment(grid,Pos.CENTER);

		enter.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				if(comboBox.getValue() != null){
					clearGUI();
					String recipient = (String)comboBox.getValue();
					int index = names.indexOf(recipient);
					System.out.println("index is: " + index);
					String messageContent = message.getText();
					String[] arrayMessage = messageContent.split(System.lineSeparator());
					ArrayList<String> list = new ArrayList<String>();
					for(int i = 0; i < arrayMessage.length; i++){
						list.add(arrayMessage[i]);
					}
					setMessage(list, "plainTextMessage.txt");
					encrypt(index);

				}else{
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Null Exception");
					alert.setHeaderText("Chose A Recipient");
					alert.show();
				}
			}

		});
	}

	private void getEncryptedMessage(){
		GridPane grid = new GridPane();
		Text text = new Text("Encrypted Message:");
		text.setTextAlignment(TextAlignment.CENTER);
		text.setFill(Color.web("#32cd32"));
		TextArea message = new TextArea();
		Button enter = new Button("Enter");
		
		getPrivateKey();

		Label label1 = new Label("You Are:");
		label1.setTextFill(Color.web("#32cd32"));
		TextField textField = new TextField (this.name);
		textField.setEditable(false);
		HBox hb = new HBox();
		hb.getChildren().addAll(label1, textField);

		grid.add(hb, 0, 0);
		grid.add(text, 0, 1);
		grid.add(message, 0, 2);
		grid.add(enter, 0, 3);
		this.setCenter(grid);
		BorderPane.setAlignment(grid,Pos.CENTER);

		enter.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				System.out.println(message.getText());
				clearGUI();
				String messageContent = message.getText();
				String[] arrayMessage = messageContent.split(System.lineSeparator());
				ArrayList<String> list = new ArrayList<String>();
				for(int i = 0; i < arrayMessage.length; i++){
					list.add(arrayMessage[i]);
				}
				setMessage(list, "encryptedMessage.txt");
				//get an arraylist of strings from message and set "plaintTextMessage.txt" to that 
				decrypt();
			}

		});
	}

	private void addUserInfo(String userName){
		getUserInfo();
		File scoreFile = new File("userList.txt");
		if(!scoreFile.exists()){
			try {
				scoreFile.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		FileWriter writeFile = null;
		BufferedWriter writer = null; //mr sea said use PrintWriter
		try{
			writeFile = new FileWriter(scoreFile);
			writer = new BufferedWriter(writeFile);
			String message = "";
			for(int i = 0; i < names.size(); i++){
				message += names.get(i) + ":" + userValues.get(i).getN() + ":" + userValues.get(i).getE() + System.lineSeparator();
			}
			KeyGeneration newUser = new KeyGeneration(); //right here is when you save your keys into a private key txt file
			message += userName + ":" + newUser.getN() + ":" + newUser.getE();
			writer.write(message);

			String userPrivateKey = userName + ":" + newUser.getN() + ":" + newUser.getD();
			ArrayList<String> privateKey = new ArrayList<String>();
			privateKey.add(userPrivateKey);
			setMessage(privateKey, "privateKey.txt");
		}catch(Exception e){

		}
		finally{
			if(writer != null){
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public void getUserInfo(){
		FileReader fileReader = null;
		//BufferedReader reader = null;
		Scanner reader = null;
		try {
			fileReader = new FileReader("userList.txt");
			reader = new Scanner(fileReader);
			names.clear();
			userValues.clear();
			//String applicableScore = "" + (width * height * 2);
			while (reader.hasNextLine()) {
				String line = reader.nextLine();
				String[] userValue = line.split(":"); //score[0] is area, score[1] is score
				names.add(userValue[0]);
				userValues.add(new KeyGeneration(new BigInteger(userValue[1]), new BigInteger(userValue[2]), false)); 
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		finally{
			if(reader != null){
				reader.close();
			}
		}
	}

	public void getPrivateKey(){
		FileReader fileReader = null;
		//BufferedReader reader = null;
		Scanner reader = null;
		try {
			fileReader = new FileReader("privateKey.txt");
			reader = new Scanner(fileReader);
			//String applicableScore = "" + (width * height * 2);
			while (reader.hasNextLine()) {
				String line = reader.nextLine();
				String[] userValue = line.split(":"); //score[0] is area, score[1] is score
				privateKeys = new KeyGeneration(new BigInteger(userValue[1]), new BigInteger(userValue[2])); 
				name = userValue[0];
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		finally{
			if(reader != null){
				reader.close();
			}
		}
	}

	public ArrayList<String> getMessage(String address){
		FileReader fileReader = null;
		//BufferedReader reader = null;
		Scanner reader = null;
		try {
			fileReader = new FileReader(address);
			reader = new Scanner(fileReader);
			ArrayList<String> userMessage = new ArrayList<String>();
			while (reader.hasNextLine()) {
				String line = reader.nextLine();
				userMessage.add(line); 
			}
			return userMessage;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} 
		finally{
			if(reader != null){
				reader.close();
			}
		}
	}

	private void setMessage(ArrayList<String> messageList, String address){
		File scoreFile = new File(address);
		if(!scoreFile.exists()){
			try {
				scoreFile.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		FileWriter writeFile = null;
		BufferedWriter writer = null; //mr sea said use PrintWriter
		try{
			writeFile = new FileWriter(scoreFile);
			writer = new BufferedWriter(writeFile);
			String message = "";

			for(int i = 0; i < messageList.size(); i++){
				message += messageList.get(i) + System.lineSeparator();
			}
			writer.write(message);
		}catch(Exception e){

		}
		finally{
			if(writer != null){
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}


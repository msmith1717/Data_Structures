import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Map.Entry;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

public class Compress extends BorderPane{
	private FileChooser chooser;
	private HashMap<Character, Integer> frequencies;
	private HashMap<Character, String> binary_grid;
	private ArrayList<String> message;
	private Huffman encoder;

	/**
	 * this method acts of the driver of the class by 
	 * initializing all attributes of the class,
	 * getting the user's input file, populating a HashMap with the input file's
	 * character frequencies, creating a Huffman class with the HashMap
	 * and printing the resulting dictionary to a file of the user's choice
	 * with the
	 */
	public Compress(){
		frequencies = new HashMap<Character, Integer>();
		binary_grid = new HashMap<Character, String>();
		message = new ArrayList<String>();
		Get_Input_File();
		encoder = new Huffman(frequencies);
		binary_grid = encoder.get_binary_grid();
		Get_Compressed_Message_Designation();
	}

	/**
	 * this method prompts the user to choose a file
	 * which contains the message they want to compress
	 * the Read-File() method is then called with this 
	 * file as a parameter
	 */
	private void Get_Input_File(){
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setHeaderText("Select a .txt file to compress");
		alert.setContentText("Select File");
		alert.showAndWait();
		chooser = new FileChooser();
		chooser.setTitle("Open Resource File");
		chooser.getExtensionFilters().add(new ExtensionFilter("Text Files", "*.txt"));	
		File file = chooser.showOpenDialog(null);
		if (file != null) {
			Read_File(file);
		}else{
			System.exit(0);
		}
	}

	/**
	 * this method reads through the input file and 
	 * populates a HashMap with the frequencies that each character 
	 * appears in the file
	 * @param file
	 */
	private void Read_File(File file){
		Scanner reader = null;
		try {
			reader = new Scanner(new FileReader(file));			
			while(reader.hasNextLine()) {
				String line = reader.nextLine();
				message.add(line);
				char[] characters = line.toCharArray();
				for(int i = 0; i < characters.length; i++){
					if(!frequencies.containsKey(characters[i])){
						frequencies.put(characters[i], 1);
					}else{
						frequencies.put(characters[i], frequencies.get(characters[i]) + 1);
					}
				}
			}
			//frequencies.put((char)27, 1);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			reader.close();
		}
	}

	/**
	 * this method prompts the user to choose a file
	 * in which they would like to their compressed values
	 * the Compress_File() method is then called with the 
	 * selected file as a parameter
	 */
	private void Get_Compressed_Message_Designation(){
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setHeaderText("Select a .txt file for storage of compressed file");
		alert.setContentText("Select File");
		alert.showAndWait();
		chooser.getExtensionFilters().add(new ExtensionFilter("Text Files", "*.txt"));	
		File file = chooser.showOpenDialog(null);
		if (file != null) {
			Compress_File(file);
		}else{
			System.exit(0);
		}

	}
	
	/**
	 * This method iterates through the file which is given
	 * as a parameter, and prints the HashMap of binary traversals that the Huffman 
	 * class calculated to that file
	 * @param file
	 */
	private void Compress_File(File file){ 
		PrintWriter writer = null;
		try{
			writer = new PrintWriter(file);
			for (Entry<Character, String> entry : this.binary_grid.entrySet()) {
				Character key = entry.getKey();
				String value = entry.getValue();
				writer.println(key + " " + value);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			writer.close();
		}
	}

	//	private void Compress_File(File file){ 
	//		PrintWriter writer = null;
	//		BitSet bit_encoder = new BitSet();
	//		int index = 0;
	//		try{
	//			writer = new PrintWriter(file);
	//			ArrayList<String> dictionary = Traversals();
	//			System.out.println(dictionary);
	//			for(int i = 0; i < dictionary.size(); i++){
	//				String entry = dictionary.get(i);
	//				if(entry.length() > 1){
	//					for(int k = 0; k < entry.length(); k++){
	//						if((index + 1) % 8 == 0){
	//							bit_encoder.set(index);
	//							index++;
	//						}
	//						if(entry.charAt(k) == '0'){
	//							bit_encoder.clear(index);
	//							System.out.println("index " + index + ": 0");
	//						}else{
	//							bit_encoder.set(index);
	//							System.out.println("index " + index + ": 1");
	//						}
	//						index++;
	//					}
	//				}else{
	//					Byte c = (byte) entry.charAt(0);
	//					String binary_string = String.format("%8s", Integer.toBinaryString(c & 0xFF)).replace(' ', '0');
	//					for(int k = 0; k < binary_string.length(); k++){
	//						if((index + 1) % 8 == 0){
	//							bit_encoder.set(index);
	//							index++;
	//						}
	//						if(binary_string.charAt(k) == '0'){
	//							bit_encoder.clear(index);
	//							System.out.println("index " + index + ": 0");
	//						}else{
	//							bit_encoder.set(index);
	//							System.out.println("index " + index + ": 1");
	//						}
	//						index++;
	//					}
	//				}
	//			}
	//			writer.println(bit_encoder.toByteArray());
	//		}catch(Exception e){
	//			e.printStackTrace();
	//		}
	//		finally{
	//			writer.close();
	//		}
	//	}

	private ArrayList<String> Traversals(){
		ArrayList<String> traversals = new ArrayList<String>();
		traversals(encoder.get_root(), "", traversals);
		return traversals;
	}

	/**
	 * this method creates an populates an arraylist of strings
	 * with the individual traversals of each leaf node
	 * if the current Huff_Node has a left child, this method is called on its
	 * left child, if it has a right child, this method is called on its right
	 * child, if it has no children (meaning it is a leaf node), then both the traversal
	 * and the character the Huff_Node represents is added to the arraylist
	 * @param node
	 * @param traversal
	 * @param traversals
	 */
	private void traversals(Huff_Node node, String traversal, ArrayList<String> traversals){
		int num_children = 0;
		if(node.get_left_child() != null){
			num_children++;
		}
		if(node.get_right_child() != null){
			num_children++;
		}
		if(num_children == 0){
			traversal += "1";
			traversal = traversal.substring(1);
			traversals.add(traversal);
			traversals.add("" + node.get_character());
		}
		if(num_children >= 1){
			traversals(node.get_left_child(), traversal + "0", traversals);
		}
		if(num_children == 2){
			traversals(node.get_right_child(), traversal + "0", traversals);
		}
	}
}

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;


public class File_System extends BorderPane{

	/**
	 * this methods initializes a Compress object when yuo press on the button
	 * the decompress button has been commented out because it was nonfunctional 
	 */
	public File_System(){
		Button compress = new Button("Compress"); 
		compress.setAlignment(Pos.CENTER);
		compress.setMinSize(50, 50);
		compress.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent arg0) { //if compressing
				Compress compress = new Compress();
			}
		});
//		Button decompress = new Button("Decompress"); 
//		decompress.setAlignment(Pos.CENTER);
//		decompress.setMinSize(50, 50);
//		decompress.setOnAction(new EventHandler<ActionEvent>(){
//			@Override
//			public void handle(ActionEvent arg0) {
//				Decompress decompress = new Decompress();
//			}
//		});
		this.setCenter(compress);
		//this.setBottom(decompress);
	}
}


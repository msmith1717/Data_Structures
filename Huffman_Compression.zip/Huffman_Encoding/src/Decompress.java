import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Scanner;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.FileChooser.ExtensionFilter;

public class Decompress extends BorderPane{
	private FileChooser chooser;
	private HashMap<Character, Integer> frequencies;
	private HashMap<Character, String> binary_grid;
	private ArrayList<String> message;

	public Decompress(){
		Get_Dictionary();
	}

	/**
	 * this method prompts the user to choose a file where
	 * their dicitonary is located, Read_File() is then called
	 * with this file as a parameter
	 */
	private void Get_Dictionary(){
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setHeaderText("Select a .txt file where dictionary is stored");
		alert.setContentText("Select File");
		alert.showAndWait();
		chooser = new FileChooser();
		chooser.setTitle("Open Resource File");
		chooser.getExtensionFilters().add(new ExtensionFilter("Text Files", "*.txt"));	
		File file = chooser.showOpenDialog(null);
		if (file != null) {
			Read_File(file);
		}else{
			//stage.close();
			//Platform.exit(); //those didnt work at all 
		}
	}

	/**
	 * this method reads an input file a byte at a time
	 * a BitSet is then used to read the individual bits of the byte
	 * a StringAppender is then populated with the values corresponding to
	 * each bit 
	 * However, this method doesn't work at all, because BitSets are weird UGH!
	 * @param file
	 */
	private void Read_File(File file){
		FileInputStream reader = null;
		BitSet bit_decoder = null;
		StringBuilder traversal = new StringBuilder();
		try {
			reader = new FileInputStream(file);
			while(true){
				int curr_val = reader.read();
				if(curr_val == -1){
					break;
				}
				//print out curr_val
				byte[] bytes = {(byte) curr_val};
				bit_decoder = BitSet.valueOf(bytes);
				for(int i = 0; i < bit_decoder.length(); i++){
					if((i + 1) % 8 != 0){
						boolean curr_bit = bit_decoder.get(i);
						if(curr_bit){
							System.out.println("1");
							traversal.append('1');
						}else{
							System.out.println("0");
							traversal.append('0');
						}
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

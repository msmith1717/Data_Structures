import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	/**
	 * this method initializes a File_System object
	 * and sets up a scene with the title File Input
	 * 
	 * 
	 */
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		File_System pane = new File_System();
		pane.setMinSize(100, 100);
		Scene scene = new Scene(pane);
		primaryStage.sizeToScene();
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.setTitle("File Input");
		primaryStage.show();
	}

}

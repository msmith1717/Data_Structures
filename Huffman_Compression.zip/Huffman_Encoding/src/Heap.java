import java.util.ArrayList;

public class Heap <T extends Comparable<T>>{
	//code as tree
	ArrayList<T> values;

	public Heap(){
		values = new ArrayList<T>();
	}

	public void insert(T object){
		values.add(object);
		int index = values.size() - 1;
		while(true){
			int parent_index = (index - 1) / 2;
			if(values.get(parent_index).compareTo(values.get(index)) == 1){
				T holder = values.get(parent_index);
				values.set(parent_index, object);
				values.set(index, holder);
				index = parent_index;
				if(index == 0){
					break;
				}
			}else{
				break;
			}
		}
	}

	public T remove(){ //check this
		if(values.size() > 0){
			T removed = values.get(0);
			values.set(0, values.get(values.size() - 1));
			values.remove(values.size() - 1);
			Heapify_Down();
			return removed;
		}else{
			return null;
		}
	}

	public void Heapify_Down(){
		if(values.size() > 0){
			T current = values.get(0);
			int curr_index = 0;
			while(true){
				int left_child_index = curr_index * 2 + 1;
				int right_child_index = curr_index * 2 + 2;
				if(left_child_index > values.size() - 1){
					break;
				}
				if(right_child_index < values.size()){
					if(values.get(right_child_index).compareTo(current) != -1 && values.get(left_child_index).compareTo(current) != -1){
						break;
					}else if(values.get(left_child_index).compareTo(current) == -1 && values.get(left_child_index).compareTo(values.get(right_child_index)) != 1){
						T holder = current;
						values.set(curr_index, values.get(left_child_index));
						values.set(left_child_index, holder);
						curr_index = left_child_index;
					}else if(values.get(right_child_index).compareTo(current) == -1 && values.get(right_child_index).compareTo(values.get(left_child_index)) == -1){
						T holder = current;
						values.set(curr_index, values.get(right_child_index));
						values.set(right_child_index, holder);
						curr_index = right_child_index;
					}
				}else{ //we know the node doesnt have a right child but does have a left child
					if(values.get(left_child_index).compareTo(current) == -1){
						T holder = current;
						values.set(curr_index, values.get(left_child_index));
						values.set(left_child_index, holder);
						curr_index = left_child_index;
					}else{
						break;
					}
				}

			}
		}
	}


}

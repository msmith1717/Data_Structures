
public class Huff_Node implements Comparable<Huff_Node>{
	private char character;
	private int frequency;
	private Huff_Node left_child;
	private Huff_Node right_child;
	
	/**
	 * this method creates a Huff_Node corresponding to the input
	 * @param character
	 * @param frequency
	 */
	public Huff_Node(char character, int frequency){
		this.character = character;
		this.frequency = frequency;
	}
	
	/**
	 * this method takes in two Huff_Nodes and creates a new Huff_Node
	 * with the sum of their frequencies
	 * @param first_removed
	 * @param second_removed
	 */
	public Huff_Node(Huff_Node first_removed, Huff_Node second_removed){
		this.left_child = first_removed;
		this.right_child = second_removed;
		this.frequency = first_removed.frequency + second_removed.frequency;
	}
	
	public Huff_Node get_right_child(){
		return right_child;
	}
	
	public Huff_Node get_left_child(){
		return left_child;
	}
	
	public char get_character(){
		return character;
	}

	/**
	 * returns -1 if parameter is greater than existing object
	 * returns 1 if parameter is less than existing object
	 * returns 0 if parameter is equal to existing object
	 */
	public int compareTo(Huff_Node o) {
		if(this.frequency < o.frequency){
			return -1;
		}else if(this.frequency > o.frequency){
			return 1;
		}
		return 0;
	}
	
	/**
	 * overrides previous toString method
	 */
	public String toString(){
		return "" + frequency;
	}
	
}

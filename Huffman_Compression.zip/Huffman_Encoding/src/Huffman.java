import java.util.HashMap;
import java.util.Map.Entry;

public class Huffman {
	private HashMap<Character, Integer> frequencies;
	private HashMap<Character, String> binary_grid;
	private Heap<Huff_Node> min_heap; 
	private Huff_Node root;
	
	/**
	 * this method takes in the frequencies calculated in the Compress class
	 * and adds the contents of that HashMap to a Heap
	 * two Huff_Nodes are removed from that Heap, combined into one Huff_Node
	 * and added back to the Heap, this process is continued until only one
	 * Huff_Node remains in the Heap
	 * @param frequencies
	 */
	public Huffman(HashMap<Character, Integer> frequencies){
		this.frequencies = frequencies;
		binary_grid = new HashMap<Character, String>();
		this.min_heap = new Heap<Huff_Node>();
		for (Entry<Character, Integer> entry : this.frequencies.entrySet()) {
			Character key = entry.getKey();
			Integer value = entry.getValue();
			min_heap.insert(new Huff_Node(key, value));
		}

		while(min_heap.values.size() > 1){
			Huff_Node first_removed = min_heap.remove();
			Huff_Node second_removed = min_heap.remove();
			Huff_Node combination = new Huff_Node(first_removed, second_removed);
			min_heap.insert(combination);
		}

		root = min_heap.values.get(0);
		traverse_root();	
	}

	public HashMap<Character, String> get_binary_grid(){
		return binary_grid;
	}

	private void traverse_root(){
		traverse_root(root, "");
	}

	/**
	 * Takes in a Huff_Node, this method is then called on any existing (non null)
	 * children that the Huff_Node has, a 0 is added to str if the method is called on the 
	 * left child, and a 1 is added to str if the method is called on the right child
	 * if no children exist, the string and the character of the Huff_Node is added
	 * to a HashMap
	 * @param node
	 * @param str
	 */
	private void traverse_root(Huff_Node node, String str){
		if(node.get_left_child() != null){
			traverse_root(node.get_left_child(), str + "0");
		}
		if(node.get_right_child() != null){
			traverse_root(node.get_right_child(), str + "1");
		}
		if(node.get_left_child() == null && node.get_right_child() == null){
			binary_grid.put(node.get_character(), str);
		}
	}
	
	public Huff_Node get_root(){
		return root;
	}

}

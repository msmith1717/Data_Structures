import java.awt.Component;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

public class file_system extends BorderPane{
	private FileChooser chooser;
	private Stage stage; 
	private BST<Integer> tree;
	private LList<Integer> nums;
	private LList<Integer> in_order;
	private LList<Integer> pre_order;
	private LList<Integer> post_order;
	private boolean quit;
	/*
	this method creates a binary search tree with the 
	values present in the first txt file passed in
	the binary search tree is then modified so all the values
	present in the second txt file are removed
	the in order, pre order, and post order traversals of the tree are then
	printed to the last txt file passed in
	 */
	public file_system(Stage stage){
		quit = false;
		this.stage = stage;
		stage.show();
		tree = new BST<Integer>();
		nums = new LList<Integer>();
		get_file_name(false, "Choose a text file to create a binary search tree");
		for(int i = 0; i < nums.size(); i++){
			tree.add(nums.get(i));
		}
		get_file_name(false, "Choose a text file to remove nums from a binary search tree"); //nums that should be removed
		for(int i = 0; i < nums.size(); i++){
			tree.remove_all(nums.get(i));
		}
		in_order = tree.inOrder();
		pre_order = tree.preOrder();
		post_order = tree.postOrder();
		get_file_name(true, "Choose a text file in which the tree will be stored");
	}

	//creates a file chooser so the user can select their desired file
	//creates a pop up with input message
	private void get_file_name(boolean write, String message){
		if(!quit){
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setHeaderText(message);
			alert.setContentText("Select File");
			alert.showAndWait();
			chooser = new FileChooser();
			chooser.setTitle("Open Resource File");
			chooser.getExtensionFilters().add( new ExtensionFilter("Text Files", "*.txt"));	
			File file = chooser.showOpenDialog(stage);
			nums.clear();
			if (file != null) {
				if(write == false){
					read_file(file);
				}else{
					write_to_file(file);
				}
			}else{
				quit = true;
				//Platform.exit();
				//return;
			}
		}
	}
	//reads the contents of the input file and adds it to an arraylist
	private void read_file(File file){
		Scanner reader = null;
		try {
			reader = new Scanner(new FileReader(file));			
			while( reader.hasNextInt()) {
				int next_int = reader.nextInt();
				nums.add(next_int);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			reader.close();
		}
	}
	//writes the contents of the three traversal arraylists in the input file
	private void write_to_file(File file){	
		PrintWriter writer = null;
		try{
			writer = new PrintWriter(file);
			writer.println("In Order Traversal: ");
			for(int i = 0; i < in_order.size(); i++){
				writer.println(in_order.get(i));
			}
			writer.println("Pre Order Traversal: ");
			for(int i = 0; i < pre_order.size(); i++){
				writer.println(pre_order.get(i));
			}
			writer.println("Post Order Traversal: ");
			for(int i = 0; i < post_order.size(); i++){
				writer.println(post_order.get(i));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			writer.close();
		}
	}
}

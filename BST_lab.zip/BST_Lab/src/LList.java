import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class LList<T> implements List<T> {
	private int size = 0;
	private Node<T> head;
	private Node<T> tail = head;

	private class LIterator<E> implements Iterator<E>{
		private Node<E> curr;

		//big o' = O(1)
		public LIterator(Node<E> node){
			curr = node;
		}

		//big o' = O(1)
		public boolean hasNext() {
			return curr != null;
		}

		//big o' = O(1)
		public E next() {	
			Node<E> lit = curr;
			curr = curr.next;
			return lit.data;
		}

	}

	private class Node<E>{
		public E data;
		public Node<E> next;
	}

	//big o' = O(1)
	public int size() {
		return size;
	}

	//big o' = O(1)
	public boolean isEmpty() {
		boolean ifNull = size == 0;
		return ifNull;
	}

	@Override
	public boolean contains(Object o) {
		return false;
	}

	//big o' = O(1)
	public Iterator<T> iterator() {
		Iterator<T> lit = new LIterator<T>(head);
		return lit;
	}

	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object[] toArray(Object[] a) {
		// TODO Auto-generated method stub
		return null;
	}

	//big o' = O(1)
	public boolean add(T e) {
		if(size == 0){
			head = new Node<T>();
			head.data = e;
		}else if(size == 1){
			head.next = new Node<T>();
			head.next.data = e;
			tail = head.next;
		}else{
			tail.next = new Node<T>(); //this line creates an infinite loop
			tail.next.data = e;
			tail = tail.next;
		}
		size++;
		return false;
	}


	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsAll(Collection c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addAll(Collection c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addAll(int index, Collection c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeAll(Collection c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean retainAll(Collection c) {
		// TODO Auto-generated method stub
		return false;
	}

	//big o' = O(1)
	public void clear() {
		// TODO Auto-generated method stub
		this.size = 0;
		head = null;
	}



	@Override
	public Object set(int index, Object element) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void add(int index, Object element) {
		// TODO Auto-generated method stub

	}

	@Override
	//big o' = O(N)
	public T remove(int index) {  
		if(index == 0){
			Node<T> removeNode = head;
			head = head.next;
			size--;
			return removeNode.data;
		}else if(index > 0 && index < size){
			T removeNode;
			Node<T> node = head;
			for(int i = 0; i < index - 1; i++){
				node = node.next;
			}
			removeNode = node.next.data;

			if(index == 0){
				head = node.next;
			}else{
				node.next = node.next.next;
				if(index == size - 1){
					tail = node;
				}
			}
			size--;
			return removeNode;
		}else{
			throw new IndexOutOfBoundsException("Index " + index + " is out of bounds!"); 
		}
	}

	@Override
	public int indexOf(Object o) {
		return 0;
	}

	@Override
	public int lastIndexOf(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ListIterator listIterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ListIterator listIterator(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List subList(int fromIndex, int toIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	//big o' = O(N)
	public T get(int index) {
		if(index < size && index >= 0){
			Node<T> node = head;
			for(int i = 0; i < index; i++){
				node = node.next;
			}
			return node.data;
		}else{
			throw new IndexOutOfBoundsException("Index " + index + " is out of bounds!");
		}
	}

}

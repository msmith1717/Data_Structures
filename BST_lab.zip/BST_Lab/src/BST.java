
public class BST<T extends Comparable<T>> {
	public BSTNode<T> root;

	public class BSTNode<E extends Comparable<E>> {
		private BSTNode<E> left;
		private BSTNode<E> right;
		private E data;

		public BSTNode(E data){
			this.data = data;
			left = null;
			right = null;
		}
		//big o' = O(1)
		//sets left child node to input
		public void setLeft(BSTNode<E> node){
			left = node;
		}
		//big o' = O(1)
		//returns left child node
		public BSTNode<E> getLeft(){
			return left;
		}
		//big o' = O(1)
		//sets right child node to input
		public void setRight(BSTNode<E> node){
			right = node;
		}
		//big o' = O(1)
		//returns right child node
		public BSTNode<E> getRight(){
			return right;
		}
		//big o' = O(1)
		//sets data to input
		public void setData(E data){
			this.data = data;
		}
		//big o' = O(1)
		//returns data of node
		public E getData(){
			return data;
		}
	}
	//big o' = O(n)
	//adds a new node with the input data to the binary search tree 
	//the new node is situated according to its value relative to the other node's values
	public void add(T data){
		if( root == null ) {
			root = new BSTNode<T>(data);
		}else{
			add(root, data );			
		}
	}
/**
 * big o'= O(n)
 * @param node
 * @param data
 * this method goes through a binary search tree
 * and calls add node on the left child if the data is less than the parents data
 * and calls add node on the right child if the data is greater or equal to the parents data
 */
	private void add(BSTNode<T> node, T data){
		if(data.compareTo(node.getData()) == -1){
			if(node.getLeft() == null){
				node.setLeft(new BSTNode<T>(data));
			}else{
				add(node.getLeft(), data);
			}
		}else{
			if(node.getRight() == null){
				node.setRight(new BSTNode<T>(data));
			}else{
				add(node.getRight(), data);
			}
		}
	}
	/**
	big o' = O(n^2)
	removes all nodes from the binary search tree with the same 
	data attribute as the input data
	**/
	public void remove_all(T data){
		boolean flag = true;
		while(flag){
			flag = remove(data);
		}
	}
	//big o' = O(n)
	//finds the first instance of a node with the passed in data
	//calls remove node with the parent of the node that is trying to be removed
	//and the node that is trying to be removed as attributes
	private boolean remove(T data){
		if(root == null){
			return false;
		}
		BSTNode<T> parent = null;
		BSTNode<T> curr = root;
		while(data.compareTo(curr.getData()) != 0){
			parent = curr;

			if(data.compareTo(curr.getData()) < 0 ){
				curr = curr.getLeft();
			}else{
				curr = curr.getRight();
			}
			if(curr == null){
				return false;
			}
		}
		return remove(parent, curr);
	}
	//big 0'= O(n)
	//removes curr from the binary search tree
	private boolean remove(BSTNode<T> parent, BSTNode<T> curr){
		int children = 0;
		if(curr.getLeft() != null){
			children++;
		}
		if(curr.getRight() != null){
			children++;
		}
		if( children <= 1 ) {
			BSTNode<T> next = curr.getLeft();
			if( curr.getLeft() == null ) {
				next = curr.getRight();
			}
			if( parent == null ) {
				root = next;
			}else {
				boolean parent_left = false;
				if(parent.getLeft() == curr){
					parent_left = true;
				}
				if(parent_left ){
					parent.setLeft(next);
				}
				else {
					parent.setRight(next);
				}
			}
		}else{//children == 2
			BSTNode<T> right_most_left_child_parent = curr;
			BSTNode<T> right_most_left_child = curr.getLeft();
			while(right_most_left_child.getRight() != null){
				right_most_left_child_parent = right_most_left_child;
				right_most_left_child = right_most_left_child.getRight();
			}
			if(parent == null){
				root.setData(right_most_left_child.getData());
			}
			curr.setData(right_most_left_child.getData());
			remove(right_most_left_child_parent, right_most_left_child);
		}
		return true;
	}
	/**
	big o' = O(n)
	returns true if the binary search tree has a node with 
	the same data attribute as the input data
	 **/
	public boolean contains(T data){
		return contains(root, data);
	}

	private boolean contains(BSTNode<T> node, T data){	
		if( node == null ){
			return false;
		}
		if(data.compareTo(node.getData()) == -1){
			return contains(node.getLeft(), data);
		}else if(data.compareTo(node.getData()) == 0){
			return true;
		}else {
			return contains(node.getRight(), data);
		}

	}
	/**
	big o' = O(n)
	returns a list of data from the tree's nodes in order of their data value
	each node's left child is visited first, then 
	the parent node, and then the node's right child
	 **/
	public LList<T> inOrder(){
		LList<T> list = new LList<T>();
		inOrder(root, list);
		return list;
	}	
	private void inOrder(BSTNode<T> node, LList<T> list){
		if(node != null){
			inOrder(node.getLeft(), list);
			list.add(node.getData());
			inOrder(node.getRight(), list);
		}
	}
	/**
	big o' = O(n)
	returns a list of data from the tree's nodes in pre order
	each parent node is visited first, then the node's left child
	then the node's right child
	 **/
	public LList<T> preOrder(){
		LList<T> list = new LList<T>();
		preOrder(root, list);
		return list;
	}

	private void preOrder(BSTNode<T> node, LList<T> list){
		if(node != null){
			list.add(node.getData());
			preOrder(node.getLeft(), list);
			preOrder(node.getRight(), list);
		}
	}
	/**
	big o' = O(n)
	returns a list of data from the tree's nodes in post order
	each node's left child is visited first, then the node's
	right child, then the parent node itself
	 **/
	public LList<T> postOrder(){
		LList<T> list = new LList<T>();
		postOrder(root, list);
		return list;
	}	

	private void postOrder(BSTNode<T> node, LList<T> list){
		if(node != null){
			postOrder(node.getLeft(), list);
			postOrder(node.getRight(), list);
			list.add(node.getData());
		}
	}

}


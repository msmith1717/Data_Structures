import java.util.List;

import com.briansea.cabinet.GameState;
import com.briansea.cabinet.Plugin;
import com.briansea.cabinet.PluginInfo;
import com.briansea.game.Move;
import com.briansea.game.Player;

public class MasonAI extends Player{

	public static PluginInfo getInfo(){
		return new PluginInfo(){

			@Override
			public String description() {
				// TODO Auto-generated method stub
				return "Mason's AI";
			}

			@Override
			public String name() {
				// TODO Auto-generated method stub
				return "Mason's AI";
			}

			@Override
			public List<Class<? extends GameState>> supportedGames() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Class<? extends Plugin> type() {
				return Player.class;
			}

		};
	}
	@Override
	public void makeMove (GameState gs, List<Move> m){
		//gs represents the current game state of the board at your turn
		//add moves that you want to make to m
		MinMaxTree tree = new MinMaxTree(gs, 7);
		if(tree.root.best_move != null){
			m.add(tree.root.best_move);
		}



	}


}



//store tree each move and keep it for next time
//you wont have to create the first few moves again

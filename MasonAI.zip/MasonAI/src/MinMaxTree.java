import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;

import com.briansea.cabinet.GameState;
import com.briansea.game.GameDim;
import com.briansea.game.Location;
import com.briansea.game.Move;
import com.briansea.game.Team;


public class MinMaxTree {
	public MMNode root;
	public Team player_one;
	public Team player_two;
	public Location curr;
	public GameDim dimensions;
	public int max_depth;
	public boolean infertility;
	public float time;
	public Timer timer;
	public float return_time;
	public int[][] board_vals;

//initiates all attributes for the min-max tree
	public MinMaxTree(GameState gs, int depth){
		board_vals = new int[][]{ 
				{2500, 500, 500, 500, 500, 500, 500, 2500},
				{500, 150, 50, 50, 50, 50, 150, 500},
				{500, 100, 3, 3, 3, 3, 100, 500},
				{500, 2, 2, 1, 1, 2, 2, 500},
				{500, 2, 2 , 1, 1, 2, 2, 500},
				{500, 100, 3, 3, 3, 3, 100, 500},
				{500, 150, 50, 50, 50, 50, 150, 500},
				{2500, 500, 500, 500, 500, 500, 500, 2500}
		};
		return_time = 4.70f;
		time = 1.0f;
		timer = new Timer();
		timer.schedule(new RemindTask(), 1000, 100);
	
		Team[] teams = gs.getPlayers();
		player_one = gs.whoseTurn().get(0);
		for(int i = 0; i < teams.length; i++){
			if(!teams[i].equals(player_one)){
				player_two = teams[i];
			}
		}

		dimensions = gs.getDimensions();
		infertility = false;
		curr = new Location();
		dimensions = gs.getDimensions();
		this.max_depth = depth;
		this.root = new MMNode(gs);
		timer.cancel();
	}
	
	class RemindTask extends TimerTask {
        public void run() {
        	if(time < return_time){
            	time += 0.10;
    			//System.out.println("Time: " + time);
    			
        	}else{
        		infertility = true;
        	}
        }
    }
	

	public class MMNode{
		public int depth;
		public boolean isMaxNode;
		public List<MMNode> children;
		public int alpha;
		public int beta;
		public Move best_move;
		public GameState node_gs;

		//need to stop populating children once a certain depth has been reached
		public MMNode(GameState gs){
			this.depth = 0;
			this.isMaxNode = true;
			this.alpha = Integer.MIN_VALUE;
			this.beta = Integer.MAX_VALUE;
			this.node_gs = gs;
			create_children(this, this.node_gs);
		}
		public MMNode(GameState gs, boolean isMaxNode, int depth, int alpha, int beta){
			this.isMaxNode = isMaxNode;
			this.depth = depth;
			this.alpha = alpha;
			this.beta = beta;
			this.node_gs = gs;
			if(depth < max_depth && !infertility){
				create_children(this, gs);
			}else if(depth == max_depth){ 
				if(this.isMaxNode){
					int eval = eval(gs);
					if(eval > this.alpha){
						this.alpha = eval;
					}
				}else{
					int eval = eval(gs);
					if(eval < this.beta){
						this.beta = eval;
					}
				}
			}
			//System.out.println("Max: " + this.isMaxNode + " , Depth: " + this.depth + ", Alpha: " + this.alpha + ", Beta: " + this.beta);
			//System.out.println("Time: " + time);
			//System.out.println("END--------------------------------------END");
		}

		public void create_children(MMNode node, GameState gs){
			List<Move> moves = gs.getValidMoves();
			node.children = new ArrayList<MMNode>();
			for(int i = 0; i < moves.size() && node.alpha < node.beta; i++){ 
				List<Move> move = new ArrayList<Move>();
				move.add(moves.get(i));
				GameState gs_sub = gs.copyInstance();
				gs_sub.makeMove(move); 
				node.children.add(new MMNode(gs_sub, !node.isMaxNode, node.depth + 1, node.alpha, node.beta)); //why does this line cause a stackoverflow error 
				if(node.isMaxNode){
					if(node.children.get(i).beta > node.alpha){ 
						node.alpha = node.children.get(i).beta;
						node.best_move = moves.get(i);
					}
				}else{
					if(node.children.get(i).alpha < node.beta){  
						node.beta = node.children.get(i).alpha;
						node.best_move = moves.get(i);
					}
				}
			}
		}	
	}

		public int eval(GameState gs){
			//the game is othello: corners are the best; dominance of the sides is good 
			//just count the number of enemy and friendly tokens	
			int state_eval = 0;
			int num_enemy = 0;
			int num_friendly = 0;
			ArrayList<Team> winner = (ArrayList<Team>) gs.getWinners();
			//System.out.println("Winner size: " + winner.size());
			if(winner.size() == 0){
				for(int i = 0; i < dimensions.width(); i++){
					for(int k = 0; k < dimensions.height(); k++){
						curr.setX(i);
						curr.setY(k);
						if(gs.getOwner(curr) != null && gs.getOwner(curr).size() > 0){
							if(gs.getOwner(curr).get(0).equals(player_one)){
								num_friendly+= board_vals[i][k];
							}else if(gs.getOwner(curr).get(0).equals(player_two)){
								num_enemy+= board_vals[i][k];
							}
						}
	
					}
	
				}
				state_eval = num_enemy - num_friendly;
			}else{
				if(winner.contains(player_one)){
					//System.out.println("max");
					return Integer.MAX_VALUE - 1;
				}else{
					//System.out.println("min");
					return Integer.MIN_VALUE + 1;
				}
			}
			return state_eval;
		}


//	public int eval(GameState gs){
//		return gs.getScore(gs.whoseTurn().get(0));
//	}

		//increases the pli of th
	public void increase_pli(){
		max_depth += 2;
		Stack<MMNode> nodes = new Stack<MMNode>();
		nodes.add(root);
		increase_pli(nodes);
	}

	public void increase_pli(Stack<MMNode> nodes){
		MMNode curr;
		boolean max_depth_reached = false;
		for(int i = 0; i < nodes.size(); i++){
			curr = nodes.get(i);
			if(!max_depth_reached){
				for(int k = 0; k < curr.children.size(); k++){
					nodes.add(curr.children.get(k));
					if(curr.children.get(k).depth == max_depth){
						max_depth_reached = true;
					}

				}
				nodes.pop();
				i--;
			}else{
				curr.create_children(curr, curr.node_gs);
			}
		}
	}

	public void recalculate_alpha_beta(){
		//didn't have enough time to finish this, so I reverted back to a timer system
	}
}

//store values in bits, instead of ints

